/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["fcg/sll/cmdtycd/manages1/controller/Exception"],
	function(Exception) {
		"use strict";

		return {
			/**
			 * Get logger instance for component
			 * @public
			 * @param {string} sDefaultComponent default component for log
			 * @returns {jQuery.sap.log.Logger} logger class
			 */
			getLogger: function(sDefaultComponent) {
				var logger;
				if (sDefaultComponent) {
					logger = jQuery.sap.log.getLogger(sDefaultComponent);
				} else {
					logger = jQuery.sap.log.getLogger("fcg.sll.cmdtycd.manages1");
					
				}
				logger.setLevel(10);
				return logger;
			},

			/**
			 * log exception
			 * @param {object} e Exception instance
			 * @public
			 */
			logException: function(e) {
				if (e instanceof Exception) {
					this.getLogger().fatal("[APP] Exception: " + e.message);
				} else {
					this.getLogger().fatal(e.message);
				}
			},

			/**
			 * log infomation
			 * @param {string} sMesssage log information
			 * @public
			 */
			debug : function(sMesssage) {
				this.getLogger().debug("[APP] Debug: " + sMesssage);
			}

		};

	});