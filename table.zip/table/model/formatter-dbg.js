/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["fcg/sll/cmdtycd/manages1/controller/BusinessConstant"], function(BusinessConstant) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		/**
		 * Check if numbering scheme content has message strip
		 * @public
		 * @param {string} sValue the numbering scheme content
		 * @returns {boolean} bVisible yes or no
		 */
		isMessageStripVisible: function(sValue) {
			switch (sValue) {
				case BusinessConstant.GTS:
					return true;
				case BusinessConstant.DataProvider:
					return true;
				default:
					break;
			}
			return false;
		},

		/**
		 * Check if numbering scheme content is transferred from GTS
		 * @public
		 * @param {string} sValue the numbering scheme content
		 * @returns {boolean} boolean yes or no
		 */
		isContentFromGTS: function(sValue) {
			if (sValue === BusinessConstant.GTS) {
				return true;
			}
			return false;
		}

	};

});