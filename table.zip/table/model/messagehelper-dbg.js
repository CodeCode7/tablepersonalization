/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/core/message/Message",
	"sap/ui/core/MessageType",
	"sap/ui/core/message/ControlMessageProcessor"
], function(Message, MessageType, ControlMessageProcessor) {
	"use strict";

	var messagehelper = {

		// * General message helper
		/**
		 * Get message manager helper
		 * @public
		 * @returns {sap.ui.core.message.MessageManager} Message Manager
		 */
		getMessageManager: function() {
			return sap.ui.getCore().getMessageManager();
		},

		/**
		 * Get message model helper
		 * @public
		 * @returns {sap.ui.core.message.MessageModel} Message Model
		 */
		getMessageModel: function() {
			return this.getMessageManager().getMessageModel();
		},

		/**
		 * Get message processor helper
		 * @public
		 * @returns {sap.ui.core.message.MessageProcessor} Message Processor
		 */
		getMessageProcessor: function() {
			var that = this;
			if (!that._oMessageProcessor) {
				that._oMessageProcessor = new ControlMessageProcessor();
				this.getMessageManager().registerMessageProcessor(this._oMessageProcessor);
			}
			return that._oMessageProcessor;
		},

		hasMessageInMessageModel: function() {
			return this.getMessageModel().getProperty("/").length > 0;
		},

		/**
		 * Return there are any error message in application or not
		 * @function
		 * @public
		 * @returns {boolean} boolean yes or no
		 */
		hasErrorMessage: function() {
			var that = this,
				aMessages = that.getMessageModel().getProperty("/").filter(
					function(oMessage) {
						return oMessage.type === MessageType.Error;
				});
			return aMessages.length > 0;
		},

		/**
		 * Message life cycle helper, remove all messages under model
		 * @function
		 * @public
		 */
		removeAllMessages: function() {
			this.getMessageManager().removeAllMessages();
		},

		/**
		 * Return there are any error message in UI check or not
		 * @function
		 * @public
		 * @returns {boolean} boolean yes or no
		 */
		hasClientValidationError: function() {
			var that = this,
				aMessages = that.getMessageModel().getProperty("/").filter(
					function(oMessage) {
						return oMessage.type === MessageType.Error && that._isClientMessage(oMessage);
				});
			return aMessages.length > 0;
		},

		// * Server message helper
		/**
		 * Message life cycle helper, remove server messages from model
		 * @function
		 * @public
		 */
		resetServerMessages: function() {
			var that = this,
				aMessages = that.getMessageModel().getProperty("/");
			aMessages.forEach(function(oMessage) {
				if (that._isServerMessage(oMessage)) {
					that.getMessageManager().removeMessages(oMessage);
				}
			});
		},

		/**
		 * Return there are any error message return by server
		 * @function
		 * @public
		 * @returns {boolean} boolean yes or no
		 */
		hasServerValidationError: function() {
			var that = this,
				aMessages = that.getMessageModel().getProperty("/").filter(
					function(oMessage) {
						return oMessage.type === MessageType.Error && that._isServerMessage(oMessage);
					});
			return aMessages.length > 0;
		},

		// * Private method
		_isClientMessage: function(oMessage) {
			return oMessage.validation;
		},

		_isServerMessage: function(oMessage) {
			return !oMessage.validation;
		}
	};
	return messagehelper;
});