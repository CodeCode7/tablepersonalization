/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["fcg/sll/cmdtycd/manages1/controller/Exception"],function(E){"use strict";return{getLogger:function(d){var l;if(d){l=jQuery.sap.log.getLogger(d);}else{l=jQuery.sap.log.getLogger("fcg.sll.cmdtycd.manages1");}l.setLevel(10);return l;},logException:function(e){if(e instanceof E){this.getLogger().fatal("[APP] Exception: "+e.message);}else{this.getLogger().fatal(e.message);}},debug:function(m){this.getLogger().debug("[APP] Debug: "+m);}};});
