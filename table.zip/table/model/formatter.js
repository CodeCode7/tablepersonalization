/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["fcg/sll/cmdtycd/manages1/controller/BusinessConstant"],function(B){"use strict";return{numberUnit:function(v){if(!v){return"";}return parseFloat(v).toFixed(2);},isMessageStripVisible:function(v){switch(v){case B.GTS:return true;case B.DataProvider:return true;default:break;}return false;},isContentFromGTS:function(v){if(v===B.GTS){return true;}return false;}};});
