/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
/* Singleton pattern */
sap.ui.define([
	"sap/ui/base/Object",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"fcg/sll/cmdtycd/manages1/model/messagehelper"
], function(Object, MessagePopover, MessagePopoverItem, messagehelper) {
	"use strict";
	var oMessagePopover,
		oMessagePopoverFactory,
		bDisableMessagePopover = false,
		_oCurrentView;
	var MessagePopoverFactory = Object.extend("fcg.sll.cmdtycd.manages1.controller.MessagePopoverFactory", {
		constructor: function() {},
		getMessagePopover: function() {
			if (!oMessagePopover || oMessagePopover.bIsDestroyed) {
				oMessagePopover = new MessagePopover({
					items: {
						path: "message>/",
						template: new MessagePopoverItem({
							description: "{message>description}",
							type: "{message>type}",
							title: "{message>message}"
						})
					}
				});
			}
			return oMessagePopover;
		}
	});
	var popoverHelper = {
		getMessagePopover: function() {
			if (!oMessagePopoverFactory) {
				oMessagePopoverFactory = new MessagePopoverFactory();
			}
			return oMessagePopoverFactory.getMessagePopover();
		},

		getDisableMessagePopover: function() {
			return bDisableMessagePopover;
		},

		setDisableMessagePopover: function(bError) {
			bDisableMessagePopover = bError;
		},

		/**
		 * Get current view the application shows
		 * @public
		 * @returns {sap.ui.core.mvc.View} current view
		 */
		getCurrentView: function() {
			return _oCurrentView;
		},

		/**
		 * Set current view the application shows
		 * The indicator which for message popover to determine the current view
		 * MUST BE SET
		 * @public
		 * @param {sap.ui.core.mvc.View} oView current view
		 */
		setCurrentView: function(oView) {
			_oCurrentView = oView;
		},

		/**
		 * Get event handler for message popover
		 * @public
		 * @returns {object} event handler function
		 */
		getEventHandlerForMessagesIndicator: function() {
			return {
				/**
				 * Event handler for navigating back.
				 * It there is a error message exist for message model, press indicator to show these message
				 * @param {sap.ui.base.Event} oEvent message indicator pressed
				 * @public
				 */
				onPressMessagesIndicator: function(oEvent) {
					var oMessagesIndicator = oEvent.getSource(),
						oPopover = popoverHelper.getMessagePopover();
					popoverHelper.addDependentsForPopover(oMessagesIndicator, oPopover);
					oPopover.toggle(oMessagesIndicator);
				}
			};
		},

		/**
		 * Attach after render for messages indicator
		 * @param {sap.m.semantic.MessagesIndicator} oMessagesIndicator Messages Indicator
		 * @param {controller} oController Error handler
		 * @function
		 * @public
		 */
		attachAfterRenderForMessagesIndicator: function(oMessagesIndicator, oController) {
			oMessagesIndicator.addEventDelegate({
				"onAfterRendering": function(o) {
					if (popoverHelper.getCurrentView() !== o.srcControl.getParent().getParent()) {
						return;
					}
					if (o.srcControl.prototype && o.srcControl.prototype.onAfterRendering) {
						o.srcControl.prototype.onAfterRendering.apply(this, arguments);
					}
					if (messagehelper.hasServerValidationError() && popoverHelper.getDisableMessagePopover()) {
						popoverHelper.openMessagePopover(o.srcControl);
						popoverHelper.setDisableMessagePopover(false);
					}
				}
			}, oController);
		},

		/**
		 * Kindly check if dependent should be refreshed, this function will lead to 
		 * Rerender of message indicators on different screens
		 * @param {sap.m.semantic.MessagesIndicator} oMessagesIndicator Message Button
		 * @param {sap.m.MessagePopover} oPopover Message Popover
		 * @function
		 * @public
		 */
		addDependentsForPopover: function(oMessagesIndicator, oPopover) {
			if (oMessagesIndicator.getDependents().indexOf(oPopover) === -1) {
				oMessagesIndicator.addDependent(oPopover);
			}
		},

		/**
		 * open message popover
		 * @param {sap.m.semantic.MessagesIndicator} oMessagesIndicator Message indicator
		 * @public
		 */
		openMessagePopover: function(oMessagesIndicator) {
			var oPopover = popoverHelper.getMessagePopover();
			if (!oPopover.isOpen()) {
				popoverHelper.addDependentsForPopover(oMessagesIndicator, oPopover);
				oPopover.openBy(oMessagesIndicator);
			}
		}
	};
	return popoverHelper;
});