/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/base/Exception",
	"sap/ui/core/MessageType"
], function(Exception, MessageType) {
	"use strict";

	/**
	 * BusinessException class
	 *
	 * This exception is thrown, when a validation error occurs while checking the
	 * defined constraints for a type.
	 * @param {String} message description
	 * @param {String} messageType message type default is error
	 * @alias fcg.sll.cmdtycd.manages1.controller.Exception
	 * @public
	 */
	var BusinessException = function(message, messageType) {
		this.name = "ValidateException";
		this.message = message;
		if (messageType) {
			this.messageType = messageType;
		} else {
			this.messageType = MessageType.Error;
		}
	};
	BusinessException.prototype = jQuery.sap.newObject(Exception.prototype);

	return BusinessException;

});