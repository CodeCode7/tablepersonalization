/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
/* eslint-disable max-params */
sap.ui.define([
	"fcg/sll/cmdtycd/manages1/controller/BaseController",
	"fcg/sll/cmdtycd/manages1/controller/Exception",
	"fcg/sll/cmdtycd/manages1/controller/ExceptionMessage",
	"fcg/sll/cmdtycd/manages1/controller/fragment/SemanticObjectController",
	"fcg/sll/cmdtycd/manages1/controller/MessagePopoverHelper",
	"fcg/sll/cmdtycd/manages1/controller/MessageBoxHelper",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/fe/navigation/SelectionVariant",
	"sap/fe/navigation/NavigationHandler",
	"sap/ui/comp/state/UIState"
], function(
	BaseController,
	Exception,
	ExceptionMessage,
	SemanticObjectController,
	MessagePopoverHelper,
	MessageBoxHelper,
	JSONModel,
	Filter,
	FilterOperator,
	MessageToast,
	SelectionVariant,
	NavigationHandler,
	UIState) {
	"use strict";

	return BaseController.extend("fcg.sll.cmdtycd.manages1.controller.Worklist", $.extend({}, SemanticObjectController, {

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var that = this,
				oViewModel,
				iOriginalBusyDelay;

			that._oResourceBundle = that.getResourceBundle();
			that._oSmartFilterBar = that.byId("SmartFilterBar");
			that._oSmartTable = that.byId("SmartTable");
			that._oTable = that.byId("tableWorklist");
			that._oLanguageSelect = that.byId("selectLanguage");
			that._oSmartTableToolBar = that.byId("SmartTabletoolbar");
			that._oMessageStrip = that.byId("messageStrip");
			that._oMessagesIndicator = that.byId("messagesIndicator");

			that.bOnInitFinished = true;
			that.initAppState();
			that.oNavigationHandler = new NavigationHandler(that);

			MessagePopoverHelper.attachAfterRenderForMessagesIndicator(that._oMessagesIndicator, that);

			oViewModel = new JSONModel({
				delay: 0,
				busy: true,
				hasSelectedItems: false,
				preventUserInteraction: false
			});
			that.setModel(oViewModel, "worklistView");
			that.setModel(that.messagehelper.getMessageModel(), "message");

			var oBindingInfo = that._oLanguageSelect.getBindingInfo("items");
			oBindingInfo.events = {
				dataReceived: that.onDataReceivedLanguage.bind(that)
			};
			that._oLanguageSelect.bindAggregation("items", oBindingInfo);
	
			that.getOwnerComponent().getModel().setSizeLimit(200);

			that.messagehelper.getMessageManager().registerObject(that.getView(), true);
			that.messagehelper.getMessageManager().registerObject(that._oLanguageSelect, true);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = that.getView().getBusyIndicatorDelay();
			that.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
				that.setBusyForView(false);
			});

			that._oLanguageInitialisePromise = new Promise(function(fnResolve) {
				that._fnLanguageInitialisedResolve = fnResolve;
			});

			that.getRouter().getRoute("worklist").attachPatternMatched(that.onWorklistMatched, that);
			that.getRouter().getRoute("localstate").attachPatternMatched(that.onWorklistMatched, that);
			that._oSmartTableToolBar.unbindElement();
		},

		/* =========================================================== */
		/* Smart filter bar event handlers                             */
		/* =========================================================== */
		/**
		 * Event handler Trigger search in case DirtyFlag is activated
		 * @param {sap.ui.base.Event} oEvent router patternMatched event
		 * @public
		 */
		onWorklistMatched: function(oEvent) {
			var that = this,
				oSelectedItemsModel = that.getOwnerComponent().getModel("selectedItems");

			MessagePopoverHelper.setCurrentView(this.getView());
			if (oSelectedItemsModel.getProperty("/DirtyFlag")) {
				oSelectedItemsModel.setProperty("/DirtyFlag", false);
				that._oSmartFilterBar.search();
				oSelectedItemsModel.setProperty("/CommodityCodes", []);
			}
			that._oTable.removeSelections(true);
			that._oTable.fireSelectionChange();
		},

		/**
		 * Event handler Rebind numbering scheme content customizing
		 * @param {sap.ui.base.Event} oEvent the SmartFilterBar afterVariantLoad event
		 * @public
		 */
		onAfterVariantLoadSmartFilterBar: function(oEvent) {
			var that = this;
			that._bindTrdClassfctnNmbrSchmCntnt();
		},

		/**
		 * Event handler attach numbering scheme content change event
		 * @param {sap.ui.base.Event} oEvent the SmartFilterBar initialise event
		 * @public
		 */
		onInitialiseSmartFilterBar: function(oEvent) {
			var that = this;
			that.getOwnerComponent().getModel().metadataLoaded().then(function() {
				var oFilter = that._oSmartFilterBar.getControlByKey("TrdClassfctnNmbrSchmCntnt");
				oFilter.attachChange(that.onChangeFilterTrdClassfctnNmbrSchmCntnt, that);
			});
			that.bFilterBarInitialized = true;
			that.initAppState();
		},

		initAppState: function () {
			// check if both init events for the controller and the SmartFilterBar have finished
			if (!(this.bFilterBarInitialized && this.bOnInitFinished)) {
				return;
			}

			var oParseNavigationPromise = this.oNavigationHandler.parseNavigation();
			var that = this;
			that._oLanguageInitialisePromise.then(function(){
				oParseNavigationPromise.done(function (oAppData, oURLParameters, sNavType) {
					if (sNavType !== sap.fe.navigation.NavType.initial) {
						var bHasOnlyDefaults = oAppData && oAppData.bNavSelVarHasDefaultsOnly;
						var oSelectionVariant = new SelectionVariant(oAppData.selectionVariant);
						var aSelectionVariantProperties = oSelectionVariant.getParameterNames().concat(oSelectionVariant.getSelectOptionsPropertyNames());
						var mUIStateProperties = {
							replace: true,
							strictMode: false
						};
						var oUiState = new UIState({
							selectionVariant: JSON.parse(oAppData.selectionVariant),
							valueTexts: oAppData.valueTexts
						});
						for (var i = 0; i < aSelectionVariantProperties.length; i++) {
							that._oSmartFilterBar.addFieldToAdvancedArea(aSelectionVariantProperties[i]);
						}
						if (!bHasOnlyDefaults || that._oSmartFilterBar.getCurrentVariantId() === "") {
							that._oSmartFilterBar.clearVariantSelection();
							that._oSmartFilterBar.clear();
							that._oSmartFilterBar.setUiState(oUiState, mUIStateProperties);
							that._bindTrdClassfctnNmbrSchmCntnt();
						}

						if (oAppData.tableVariantId) {
							that._oSmartTable.setCurrentVariantId(oAppData.tableVariantId);
						}
						if (oAppData.customData && oAppData.customData.tablePresentationVariant) {
							var oTableUiState = new UIState({
								selectionVariant: JSON.parse(oAppData.customData.tableSelectionVariant),
								presentationVariant: JSON.parse(oAppData.customData.tablePresentationVariant)
							});
							that._oSmartTable.setUiState(oTableUiState);
						}

						that.restoreCustomAppStateData(oAppData.customData);
						if (!bHasOnlyDefaults) {
							that._oSmartFilterBar.search();
						}
					}
			});

				oParseNavigationPromise.fail(function (oError) {
					that._handleError(oError);
				});
			});
		},

		_handleError: function (oError) {
			// TBD.
		},

		/**
		 * Changes the URL according to the current app state and stores the app state for later retrieval.
		 */
		storeCurrentAppState: function () {
			var oAppStatePromise = this.oNavigationHandler.storeInnerAppState(this.getCurrentAppState());
			oAppStatePromise.done(function (sAppStateKey) {
				//your inner app state is saved now; sAppStateKey was added to URL
				//perform actions that must run after save
			}.bind(this));
			oAppStatePromise.fail(function (oError) {
				this._handleError(oError);
			}.bind(this));
			return oAppStatePromise;
		},

		/**
		 * @returns {object} the current app state consisting of the selection variant, the table variant and additional custom data
		 */
		getCurrentAppState: function () {
			var oSelectionVariant = new SelectionVariant(JSON.stringify(this._oSmartFilterBar.getUiState().getSelectionVariant()));
			return {
				selectionVariant: oSelectionVariant.toJSONString(),
				valueTexts: this._oSmartFilterBar.getUiState().getValueTexts(),
				tableVariantId: this._oSmartTable.getCurrentVariantId(),
				customData: this.getCustomAppStateData()
			};
		},

		getCustomAppStateData: function () {
			if( this.byId("SmartTable-variant") &&
			    this.byId("SmartTable-variant").currentVariantGetModified() ) {
				return {
					// store the information if the fitler bar variant is dirty as part of the custom data
					filterBarVariantDirty: this.byId("smartVariantManagement").currentVariantGetModified(),
					// storte the table UI state as part of the custom data
					tableSelectionVariant: JSON.stringify(this._oSmartTable.getUiState().getSelectionVariant()),
					tablePresentationVariant: JSON.stringify(this._oSmartTable.getUiState().getPresentationVariant())
					// add app specific custom data for back navigation if necessary
				};
			} else {
				return {
					// store the information if the fitler bar variant is dirty as part of the custom data
					filterBarVariantDirty: this.byId("smartVariantManagement").currentVariantGetModified()
					// add app specific custom data for back navigation if necessary
				};
			}

		},

		restoreCustomAppStateData: function (oCustomData) {
			// perform custom logic for restoring the custom data of the app state
		},

		onAfterApplyTableVariant: function (oEvent) {
			// write inner app state
			this.storeCurrentAppState();
		},

		onBeforeVariantFetch: function (oEvent) {
			// TBD.
		},

		onSearch: function (oEvent) {
			var that = this;
			// write inner app state
			that.storeCurrentAppState();
		},

		/**
		 * Event handler numbering scheme content change event
		 * @param {sap.ui.base.Event} oEvent the Filter change event
		 * @public
		 */
		onChangeFilterTrdClassfctnNmbrSchmCntnt: function() {
			var that = this;
			that._bindTrdClassfctnNmbrSchmCntnt();
		},

		/**
		 * Event handler side effect of language change
		 * @param {sap.ui.base.Event} oEvent selection box change event
		 * @public
		 */
		onChangeLanguage: function() {
			var that = this;
			if (!that.getModel("worklistView").getProperty("/preventUserInteraction") &&
				that._oTable.getBinding("items")) {
				that._oSmartFilterBar.search();
			}
		},

		/**
		 * Event handler indicate error in case language is not received
		 * @param {sap.ui.base.Event} oEvent binding dataReceivedLanguage event
		 * @public
		 */
		onDataReceivedLanguage: function(oEvent) {
			var that = this,
				data = oEvent.getParameter("data");
			if (data && data.results && data.results.length < 1) {
				that._oLanguageSelect.setValueState("Error");
			} else {
				var oSelectedItemsModel = that.getOwnerComponent().getModel("selectedItems");
				if (!oSelectedItemsModel.getProperty("/Language")) {
					oSelectedItemsModel.setProperty("/Language", sap.ui.getCore().getConfiguration().getSAPLogonLanguage().toUpperCase());
				}
			}
			that._fnLanguageInitialisedResolve();
		},

		/* =========================================================== */
		/* Smart table event handlers                                  */
		/* =========================================================== */

		/**
		 * Event handler bind language filter option before query
		 * @param {sap.ui.base.Event} oEvent the smart table beforeRebindTable event
		 * @public
		 */
		onBeforeRebindTable: function(oEvent) {
			var that = this,
				mParameter = oEvent.getParameter("bindingParams"),
				oSelectedItems = that.getOwnerComponent().getModel("selectedItems"),
				sLanguageKey = oSelectedItems.getProperty("/Language");

			// Add Language to filters
			mParameter.filters.push(
				new Filter({
					path: "Language",
					operator: FilterOperator.EQ,
					value1: sLanguageKey
				})
			);

			// Set sorter for Edit Page
			if (mParameter.sorter) {
				oSelectedItems.setProperty("/Sorters", mParameter.sorter);
			}
		},

		/**
		 * Event handler enable language switch side effect
		 * @param {sap.ui.base.Event} oEvent the smart table dataReceivedSmartTable event
		 * @public
		 */
		onDataReceivedSmartTable: function(oEvent) {
			var that = this;
			that._updateInlineActionStatus();
		},

		/**
		 * Event handler when table selection changed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onSelectionChange: function(oEvent) {
			this._updateInlineActionStatus();
		},

		/**
		 * Event handler trgger navigation to next screen
		 * @param {sap.ui.base.Event} oEvent create button press event
		 * @public
		 */
		onPressCreateBtn: function(oEvent) {
			this._navToCreatePage();
		},

		/**
		 * Event handler trgger navigation to next screen
		 * @param {sap.ui.base.Event} oEvent edit button press event
		 * @public
		 */
		onPressEditBtn: function(oEvent) {
			var that = this,
				aSelectedItems = that._oTable.getSelectedItems(),
				sMessage = that.getResourceBundle().getText("msgSelectLimitationDialogEditText", that._oTable.getGrowingThreshold());

			if (aSelectedItems.length >= 200) {
				MessageBoxHelper.showMessageBoxSelectLimitation(sMessage, that._navToEditPage, that);
				return;
			} else {
				that._navToEditPage();
			}
		},

		/**
		 * Event handler trgger delete function for selected items
		 * @param {sap.ui.base.Event} oEvent create button press event
		 * @public
		 */
		onPressDeleteBtn: function(oEvent) {
			var that = this,
				aSelectedItems = that._oTable.getSelectedItems(),
				sMessageBoxId,
				sMessageBoxText;

			// _silenceMode is private function for test only
			if (jQuery.sap.getUriParameters().get("_silenceMode")) {
				that.logger.getLogger().warning("[APP] Slience Mode is activated");
				that._deleteCommodityCodes();
				return;
			}

			if (aSelectedItems.length >= 200) {
				sMessageBoxText = that.getResourceBundle().getText("msgPartialDeleteTheEntries", that._oTable.getGrowingThreshold());
				sMessageBoxId = "confirmPartialDeleteMessageBox";
			} else {
				sMessageBoxText = that.getResourceBundle().getText("msgDeleteTheEntries", that._oTable.getGrowingThreshold());
				sMessageBoxId = "confirmDeleteMessageBox";
			}

			MessageBoxHelper.showMessageBoxConfirmDeletion(sMessageBoxId, sMessageBoxText, that._deleteCommodityCodes, that);
		},

		/**
		 * Set busy for worklist
		 * @param {boolean} bBusy indicator
		 * @public
		 */
		setBusyForView: function(bBusy) {
			var that = this;
			that.getModel("worklistView").setProperty("/busy", bBusy);
		},

		refreshWorklistForNotFound: function() {
			var that = this;
			that.logger.debug("[NOTFOUND] Step 2: Refresh Model Started");
			that.resetRefreshModelForNotFound();
			// After model refresh the selected context are cleared
			that._oSmartFilterBar.search();
			that.logger.debug("[NOTFOUND] Step 3: Data inconsistance is not resolvable with paging");
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * navigation to edit page
		 * @private
		 */
		_navToEditPage: function() {
			var that = this,
				oSelectedItems = that.getOwnerComponent().getModel("selectedItems"),
				oFilter = that._oSmartFilterBar.getControlByKey("TrdClassfctnNmbrSchmCntnt"),
				aCommodityCodes = [];
			try {
				aCommodityCodes = that._getSelectedCommodityCodes();
				oSelectedItems.setProperty("/CommodityCodes", aCommodityCodes);
				oSelectedItems.setProperty("/TrdClassfctnNmbrSchmCntnt", oFilter.getValue());
				// Language key updated by property binding
				// oSelectedItems.setProperty("/Language", that._oLanguageSelect.getSelectedKey());
				this.getRouter().navTo("editPage");
			} catch (e) {
				// Catch Exception if no item is loaded
				that.logger.logException(e);
			}
		},

		/**
		 * navigation to create page
		 * @private
		 */
		_navToCreatePage: function() {
			var that = this,
				oSelectedItems = that.getOwnerComponent().getModel("selectedItems"),
				oFilter = that._oSmartFilterBar.getControlByKey("TrdClassfctnNmbrSchmCntnt");

			oSelectedItems.setProperty("/TrdClassfctnNmbrSchmCntnt", oFilter.getValue());
			// Language key updated by property binding
			oSelectedItems.setProperty("/Language", that._oLanguageSelect.getSelectedKey());
			this.getRouter().navTo("createPage");
		},

		/**
		 * Create the path for numbering scheme content
		 * @private
		 * @returns {string} path for numbering cheme content
		 */
		_createPathForTrdClassfctnNmbrSchmCntnt: function() {
			var that = this,
				oFilterTrdClassfctnNmbrSchmCntnt = that._oSmartFilterBar.getControlByKey("TrdClassfctnNmbrSchmCntnt"),
				sPath = "TrdClassfctnNmbrSchmCntntActnCtrlSet";
			sPath = "/" + that.getModel().createKey(sPath, {
				TrdClassfctnNmbrSchmCntnt: oFilterTrdClassfctnNmbrSchmCntnt.getValue()
			});
			return sPath;
		},

		/**
		 * bind numbering scheme content to create button and message strip
		 * @private
		 */
		_bindTrdClassfctnNmbrSchmCntnt: function() {
			var that = this,
				sPath = "";

			that._oSmartTableToolBar.unbindElement();
			that._oMessageStrip.unbindElement();

			try {
				if (that._oSmartFilterBar.verifySearchAllowed().error) {
					throw new Exception(ExceptionMessage.SmartFilterBarVerifyError);
				}
				sPath = that._createPathForTrdClassfctnNmbrSchmCntnt();
				that._oSmartTableToolBar.bindElement({
					path: sPath,
					events: {
						dataRequested: function() {
							that.setBusyForView(true);
						},
						dataReceived: function(oEvent) {
							that.setBusyForView(false);
						}
					}
				});
				that._oMessageStrip.bindElement(sPath);
			} catch (e) {
				that.logger.logException(e);
			}
		},

		/**
		 * Event handler delete Commodity Codes
		 * @param {sap.ui.base.Event} oEvent binding delete button press event
		 * @private
		 */
		_deleteCommodityCodes: function(oEvent) {
			var that = this,
				oModel = that.getModel(),
				sGroupId = "DELETEITEMS",
				aDeferredGroups = oModel.getDeferredGroups(),
				aSelectedItems = that._oTable.getSelectedItems(),
				oContext,
				mParameters,
				iDeleteItemsCount = 0;

			// Push delete items and delete duplicated groupid
			aDeferredGroups.push(sGroupId);
			aDeferredGroups = aDeferredGroups.filter(function(item, pos) {
				return aDeferredGroups.indexOf(item) === pos;
			});
			oModel.setDeferredGroups(aDeferredGroups);
			aSelectedItems.forEach(function(oSelectedItem, iIndex) {
				if (iIndex <= that._oTable.getGrowingThreshold() - 1) {
					oContext = oSelectedItem.getBindingContext();
					oModel.remove(oContext.getPath(), {
						context: oContext,
						groupId: sGroupId
						// eTag: "*"
					});
				}
			});
			that.setBusyForView(true);
			that.messagehelper.resetServerMessages();
			mParameters = {
				groupId: sGroupId,
				success: function(oEvt) {
					that.setBusyForView(false);
					// Refresh model incase resource is deleted
					if (that.getRefreshModelForNotFound()) {
						that.refreshWorklistForNotFound();
						return;
					}
					if (that.messagehelper.hasErrorMessage()) {
						return;
					}
					iDeleteItemsCount = oEvt.__batchResponses[0].__changeResponses.length;
					that._showDeleteSuccessInfo(iDeleteItemsCount);
					that._oSmartFilterBar.search();
				},
				error: function(oEvt) {
					that.setBusyForView(false);
				}
			};
			oModel.submitChanges(mParameters);
		},

		/**
		 * Function information after deleting successfully
		 * @param {int} iDeleteItemsCount count of deleted items
		 * @private
		 */
		_showDeleteSuccessInfo: function(iDeleteItemsCount) {
			var that = this,
				sMessage = "";
			sMessage = that.getResourceBundle().getText("msgDelete", [iDeleteItemsCount]);
			MessageToast.show(sMessage);
		},

		/**
		 * Get selected Commodity Codes
		 * @private
		 * @returns {array} selected Commodity Codes
		 */
		_getSelectedCommodityCodes: function() {
			var that = this,
				aSelectedItems = that._oTable.getSelectedItems(),
				aCommodityCodes = [],
				oContext;

			aSelectedItems.forEach(function(oSelectedItem, iIndex) {
				if (iIndex <= that._oTable.getGrowingThreshold() - 1) {
					oContext = oSelectedItem.getBindingContext();
					if (oContext) {
						aCommodityCodes.push(oContext.getObject());
					} else {
						throw new Exception(ExceptionMessage.NoItemIsLoaded);
					}
				}
			});
			return aCommodityCodes;
		},

		_updateInlineActionStatus: function() {
			var that = this,
				oViewModel = that.getModel("worklistView");
			oViewModel.setProperty("/hasSelectedItems", that._oTable.getSelectedItems().length > 0);
		}

	}));
});