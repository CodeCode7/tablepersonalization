/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(function() {
	"use strict";
	/**
	 * Exception Messages
	 *
	 * @enum {string}
	 * @public
	 * @alias fcg.sll.cmdtycd.manages1.controller.ExceptionMessage
	 */
	var ExceptionMessage = {
		/**
		 * ExceptionMessage no numbering scheme
		 * @public
		 */
		NoTrdClassfctnNmbrSchmCntnt: "No numbering scheme content identified",

		/**
		 * ExceptionMessage no language
		 * @public
		 */
		NoLanguage: "No language identified",

		/**
		 * ExceptionMessage no Commodity Codes
		 * @public
		 */
		NoCommodityCodes: "No Commodity Codes selected",

		/**
		 * ExceptionMessage no item is loaded
		 * @public
		 */
		NoItemIsLoaded: "Item is not loaded",

		/**
		 * ExceptionMessage invalid numbering scheme content is inputed
		 * @public
		 */
		InvalidTrdClassfctnNmbrSchmCntnt: "Invalid numbering scheme content is inputed",

		/**
		 * ExceptionMessage Server conflict
		 * @public
		 */
		// ServerConcurrencyConflict: "ServerConcurrencyConflict",
		ServerInternalErrorCanBeResolved: "ServerInternalErrorCanBeResolved",
		ServerResourceNotFound: "ServerResourceNotFound",
		ServerResourceLocked: "ServerResourceLocked",
		ServerBadRequest: "ServerBadRequest",

		getMessageFunctionNotImplemented: function(sFunctionName) {
			return "The function " + sFunctionName + " is an abstract function which needs to be implemented by subclasses.";
		}

	};

	return ExceptionMessage;

}, /* bExport= */ true);