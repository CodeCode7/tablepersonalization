/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
/*global location*/
sap.ui.define([
	"fcg/sll/cmdtycd/manages1/controller/DataModelController",
	"fcg/sll/cmdtycd/manages1/controller/Exception",
	"fcg/sll/cmdtycd/manages1/controller/ExceptionMessage",
	"fcg/sll/cmdtycd/manages1/controller/MessagePopoverHelper",
	"fcg/sll/cmdtycd/manages1/model/formatter",
	"sap/ui/model/json/JSONModel"
], function(
	DataModelController,
	Exception,
	ExceptionMessage,
	MessagePopoverHelper,
	formatter,
	JSONModel
) {
	"use strict";

	return DataModelController.extend("fcg.sll.cmdtycd.manages1.controller.CreatePage", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var that = this,
				iOriginalBusyDelay,
				oViewModel;

			DataModelController.prototype.onInit.call(that);

			that._oTable = that.byId("tableCreate");

			that.getRouter().getRoute("createPage").attachPatternMatched(that._onObjectMatched, that);

			oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				table: {
					oListItemTemplate: that._oTable.getItems()[0].clone(this.getView().createId("CodeMasterItem"))
				}
			});

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = that.getView().getBusyIndicatorDelay();
			that.setModel(oViewModel, "createPageView");
			that.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when context is deleted or created
		 * @param {sap.ui.base.Event} oEvent the Context modelContextChange event
		 * @public
		 */
		onModelContextChange: function(oEvent) {
			var that = this;

			// Update Model Change
			that.hasPendingChanges();
		},

		/**
		 * Event handler when add button is pressed
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onPressAddIcon: function(oEvent) {
			var that = this,
				oAddBtn = oEvent.getSource(),
				oSelectedListItem = oAddBtn.getParent(),
				oSelectedEntryContext = oSelectedListItem.getBindingContext(),
				oListItemRendered = new Promise(function(fnResolve) {
					that._fnListItemRenderedResolve = fnResolve;
				}),
				oDelegate = {
					"onAfterRendering": function(oEve) {
						if (oEve.srcControl.prototype && oEve.srcControl.prototype.onAfterRendering) {
							oEve.srcControl.prototype.onAfterRendering.apply(this, arguments);
						}
						oEve.srcControl.focus();
						that._fnListItemRenderedResolve();
					}
				};

			if (that.hasLineItemPendingDateError(oSelectedListItem)) {
				return;
			}

			var oNewEntryContext = that._createEntryForCommodityCode(
					oSelectedEntryContext.getProperty("ValidityStartDate"),
					oSelectedEntryContext.getProperty("ValidityEndDate")
				),
				oNewListItem = that._cloneListItemFromTemplate(oNewEntryContext);

			// Valid from and valid to are taken from previous object automatically.
			// Append item to the end of list 
			that.getTable().insertItem(oNewListItem, that.getTable().getItems().length);

			oNewListItem.addEventDelegate(oDelegate, that);
			oListItemRendered.then(function() {
				oNewListItem.removeEventDelegate(oDelegate);
			});

			// Set Add button invisible
			oAddBtn.setVisible(false);

		},

		/**
		 * Event handler when remove icon is pressed
		 * @param {sap.ui.base.Event} oEvent the icon press event
		 * @public
		 */
		onPressRemoveIcon: function(oEvent) {
			var that = this,
				oRemoveIcon = oEvent.getSource(),
				oListItem = oRemoveIcon.getParent();

			that._removeItem(oListItem);

		},
		/**
		 * Event remove all empty items before submit changes
		 * @function
		 */
		removeEmptyItems: function() {
			var that = this,
				aItems = that.getTable().getItems();
			aItems.forEach(function(oListItem) {
				if (!that._hasChangeInRow(oListItem)) {
					that._removeItem(oListItem);
				}
			});
		},

		/*
		 * overridden with create page hasPendingChanges
		 * @name fcg.sll.cmdtycd.manages1.controller.CreatePageController#hasPendingChanges
		 * @function
		 * @returns {boolean} boolean yes or no
		 */
		hasPendingChanges: function() {
			var that = this,
				bChange = false,
				aListItems;

			aListItems = that.getTable().getItems().filter(that._hasChangeInRow.bind(that));

			bChange = aListItems.length > 0;

			sap.ushell.Container.setDirtyFlag(bChange);
			return bChange;

		},

		/*
		 * overridden with create page getTable
		 * @name fcg.sll.cmdtycd.manages1.controller.CreatePageController#getTable
		 * @function
		 * @returns {sap.ui.table.Table} table object
		 */
		getTable: function() {
			return this._oTable;
		},

		/*
		 * overridden with create page setBusyForView
		 * @name fcg.sll.cmdtycd.manages1.controller.CreatePageController#setBusyForView
		 * @function
		 */
		setBusyForView: function(bBusy) {
			var that = this;
			that.getModel("createPageView").setProperty("/busy", bBusy);
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var that = this,
				sOptionalQueryString = oEvent.getParameter("arguments")["?OptionalQueryString"],
				sTrdClassfctnNmbrSchmCntnt = that.getTrdClassfctnNmbrSchmCntnt(sOptionalQueryString),
				sLanguage = that.getLanguage(sOptionalQueryString);

			MessagePopoverHelper.setCurrentView(this.getView());
			that.messagehelper.removeAllMessages();
			try {
				that._bindView(sTrdClassfctnNmbrSchmCntnt, sLanguage);
			} catch (e) {
				that.logger.logException(e);
				that.onNavBack();
			}

		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sTrdClassfctnNmbrSchmCntnt numbering scheme content 
		 * @param {string} sLanguage language
		 * @private
		 */
		_bindView: function(sTrdClassfctnNmbrSchmCntnt, sLanguage) {
			var that = this;

			if (!sTrdClassfctnNmbrSchmCntnt) {
				throw new Exception(ExceptionMessage.NoTrdClassfctnNmbrSchmCntnt);
			}

			if (!sLanguage) {
				throw new Exception(ExceptionMessage.NoLanguage);
			}

			// Bind language text
			that.getModel().metadataLoaded().then(function() {
				var sLanguagePath = that.getModel().createKey("I_Language", {
					Language: sLanguage
				});

				that.getModel().resetChanges();

				that.byId("languageText").bindElement("/" + sLanguagePath);

				var oNewEntryContext = that._createEntryForCommodityCode();

				that.getTable().bindElement({
					path: that.createPathForTrdClassfctnNmbrSchmCntnt(),
					events: {
						dataRequested: function() {
							that.setBusyForView(true);
						},
						dataReceived: function(oEvent) {
							that.setBusyForView(false);
						}
					}
				});
				that.getTable().destroyItems();
				that.getTable().insertItem(that._cloneListItemFromTemplate(oNewEntryContext));

			});

		},

		/**
		 * clone a new item from template
		 * @function
		 * @param {sap.ui.model.Context} oNewEntryContext points to new entry
		 * @private
		 * @returns {sap.m.ColumnListItem} new item in create page table
		 */
		_cloneListItemFromTemplate: function(oNewEntryContext) {
			var that = this,
				oViewModel = that.getModel("createPageView"),
				oListItemTemplate = oViewModel.getProperty("/table/oListItemTemplate"),
				oNewListItem = oListItemTemplate.clone();
			oNewListItem.setBindingContext(oNewEntryContext);
			oNewListItem.getCells().forEach(function(oCell) {
				sap.ui.getCore().getMessageManager().registerObject(oCell, true);
			});
			return oNewListItem;
		},

		/**
		 * Create new Commodity Code entry
		 * @function
		 * @param {object} dValidityStartDate validity from
		 * @param {object} dValidityEndDate validity to
		 * @private
		 * @returns {sap.ui.model.Context} A context object points to new Commodity Code
		 */
		_createEntryForCommodityCode: function(dValidityStartDate, dValidityEndDate) {
			var that = this,
				oDataModel = that.getModel(),
				oSelectedItemsModel = that.getOwnerComponent().getModel("selectedItems"),
				sTrdClassfctnNmbrSchmCntnt = oSelectedItemsModel.getProperty("/TrdClassfctnNmbrSchmCntnt"),
				sUnitOfMeasureSystemPath = that.createPathForTrdClassfctnNmbrSchmCntnt() + "/UnitOfMeasureSystem",
				oContext = oDataModel.createEntry("C_CommodityCodeByLanguage");

			oDataModel.setProperty(oContext.getPath() + "/Language", oSelectedItemsModel.getProperty("/Language"));
			oDataModel.setProperty(oContext.getPath() + "/TrdClassfctnNmbrSchmCntnt", sTrdClassfctnNmbrSchmCntnt);
			oDataModel.setProperty(oContext.getPath() + "/UnitOfMeasureSystem", oDataModel.getProperty(sUnitOfMeasureSystemPath));
			if (dValidityStartDate) {
				oDataModel.setProperty(oContext.getPath() + "/ValidityStartDate", dValidityStartDate);
			}
			if (dValidityEndDate) {
				oDataModel.setProperty(oContext.getPath() + "/ValidityEndDate", dValidityEndDate);
			}
			// Work around, worklist required text fields. But in mock, create case will not fulfill this property
			for (var key in oContext.getObject()) {
				if(key.indexOf("_Text") > -1){
					oDataModel.setProperty(oContext.getPath() + "/" + key, "");
				}
			}
			return oContext;
		},

		/**
		 * Has change in row
		 * @function
		 * @param {object} oRow row object
		 * @private
		 * @returns {boolean} boolean yes or no
		 */
		_hasChangeInRow: function(oRow) {
			var bHasChange = false,
				aCell = oRow.getCells();
			aCell.forEach(function(oCell){
				if(oCell.getMetadata().getName() === "sap.ui.comp.smartfield.SmartField" && oCell.getValue()){
					bHasChange = true;
				}
			});
			return bHasChange;
		},

		/**
		 * Remove item in table of create page
		 * @function
		 * @param {sap.m.ColumnListItem} oListItem Commodity Code table entry
		 * @private
		 */
		_removeItem: function(oListItem) {
			var that = this,
				aListItems = that.getTable().getItems(),
				oListItemContext = oListItem.getBindingContext();

			// Remove context binding
			if (aListItems.length === 1) {
				oListItem.unbindContext();
				that.getModel().deleteCreatedEntry(oListItemContext);
				oListItem.setBindingContext(that._createEntryForCommodityCode());
			} else {
				// Exception for oListItemContext.bCreate === false
				// Delete existing entry should use another API
				that.getModel().deleteCreatedEntry(oListItemContext);
				that.getTable().removeItem(oListItem);
			}

			// Set add button visible
			var oListItemByIndex = aListItems.slice(-2)[0],
				aControlInFieldGroup;
			if (oListItem !== aListItems.slice(-1)[0] || !oListItemByIndex) {
				return;
			}
			aControlInFieldGroup = sap.ui.getCore().byFieldGroupId("fieldGroupAddBtn").filter(function(oControl) {
				try {
					if (typeof oControl.getText === "function" &&
						oControl.getBindingInfo("text").parts[0].path === "btnAdd" &&
						oControl.getBindingContext() === oListItemByIndex.getBindingContext()) {
						return true;
					}
				} catch (e) {
					that.logger.logException(e);
				}
				return false;
			});
			if (aControlInFieldGroup.length > 0) {
				aControlInFieldGroup[0].setVisible(true);
			}
		}

	});

});