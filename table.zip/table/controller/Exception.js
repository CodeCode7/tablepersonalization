/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["sap/ui/base/Exception","sap/ui/core/MessageType"],function(E,M){"use strict";var B=function(m,a){this.name="ValidateException";this.message=m;if(a){this.messageType=a;}else{this.messageType=M.Error;}};B.prototype=jQuery.sap.newObject(E.prototype);return B;});
