/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["fcg/sll/cmdtycd/manages1/controller/BaseController"],function(B){"use strict";return B.extend("fcg.sll.cmdtycd.manages1.controller.NotFound",{onLinkPressed:function(){this.getRouter().navTo("worklist");}});});
