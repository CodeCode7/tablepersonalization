/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(function(){"use strict";var E={NoTrdClassfctnNmbrSchmCntnt:"No numbering scheme content identified",NoLanguage:"No language identified",NoCommodityCodes:"No Commodity Codes selected",NoItemIsLoaded:"Item is not loaded",InvalidTrdClassfctnNmbrSchmCntnt:"Invalid numbering scheme content is inputed",ServerInternalErrorCanBeResolved:"ServerInternalErrorCanBeResolved",ServerResourceNotFound:"ServerResourceNotFound",ServerResourceLocked:"ServerResourceLocked",ServerBadRequest:"ServerBadRequest",getMessageFunctionNotImplemented:function(f){return"The function "+f+" is an abstract function which needs to be implemented by subclasses.";}};return E;},true);
