/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(function() {
	"use strict";

	return {

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * Event handler when ok button in dialog is pressed
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onDialogPressBtnOK: function() {
			var that = this,
				oDialog = that.getView().byId("dialogSetValidityEndDate"),
				oDatePicker = that.getView().byId("datePickerInDialog");
			oDatePicker.checkValuesValidity().then(function(){
				var dDate = oDialog.getBindingContext().getProperty("ValidityEndDate");
				that.setDateForAllListItems(dDate);
				// setProperty will not trigger propertyChange event
				// So we set dirty flag manually
				that.hasPendingChanges();
				oDialog.close();
			});
		},

		/**
		 * Event handler when cancel button in dialog is pressed
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onDialogPressBtnCancel: function() {
			var oDialog = this.getView().byId("dialogSetValidityEndDate");
			oDialog.close();
		},

		/**
		 * Event handler when dialog is closed
		 * @param {sap.ui.base.Event} oEvent the Context afterClose event
		 * @public
		 */
		onDialogAfterClose: function() {
			var oDialog = this.getView().byId("dialogSetValidityEndDate");
			this.getView().getModel().resetChanges([oDialog.getBindingContext().getPath()], true);
			oDialog.destroy();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/*
		 * Set date for all selected items
		 * @name fcg.sll.cmdtycd.manages1.controller.DialogSetValidityEndDate#setDateForAllListItems
		 * @function
		 */
		setDateForAllListItems: function(dDate) {
			var that = this,
				aListItems = that.getTable().getItems(),
				oDataModel = that.getModel();
			aListItems.forEach(function(oListItems) {
				var oContext = oListItems.getBindingContext(),
					sPath = oContext.getPath();
				oDataModel.setProperty(sPath + "/ValidityEndDate", dDate, oContext, true);
				// that.validateRowChange(sPath);
			});
		}
	};
});