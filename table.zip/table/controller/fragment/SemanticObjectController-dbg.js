/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(function() {
	"use strict";

	return {

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * Event handler load semantic attributes and trigger open event
		 * @param {sap.ui.base.Event} oEvent the SemanticObjectController beforePopoverOpens event
		 * @public
		 */
		onBeforePopoverOpens: function(oEvent) {
			var aParameters = oEvent.getParameters(),
				aSemanticAttributes = aParameters.semanticAttributes;
			aParameters.setSemanticAttributes(aSemanticAttributes);
			aParameters.open();
		},

		/**
		 * Event handler provide additional form for popover
		 * @param {sap.ui.base.Event} oEvent the SemanticObjectController navigationTargetsObtained event
		 * @public
		 */
		onNavigationTargetsObtained: function(oEvent) {
			var that = this,
				aParameters = oEvent.getParameters(),
				oFragment = that._createFormsFragment(),
				oModel = that.getModel(),
				sCodeMasterPath = "/" + oModel.createKey("C_CommodityCodeByLanguage", aParameters.semanticAttributes),
				oEntityType = oModel.getMetaModel().getODataEntityType("SLL_CMDTYCD_MANAGE.C_CommodityCodeByLanguageType"),
				sExpand = oEntityType && oEntityType.navigationProperty && oEntityType.navigationProperty.map(
					function(elem){ return elem.name; }).join(",");
			oModel.invalidateEntry(sCodeMasterPath);
			oFragment.bindElement({
				path: sCodeMasterPath,
				parameters: {
					expand: sExpand
				},
				// TODO: Decouple dependency with worklist
				events: {
					dataReceived: function(oEvt) {
						if (!oEvt.getParameter("data")) {
							that.refreshWorklistForNotFound();
						}
					}
				}
			});
			aParameters.show(null, [], oFragment);
		},

		/* =========================================================== */
		/* internal method                                             */
		/* =========================================================== */
		_createFormsFragment: function() {
			var that = this,
				oView = that.getView(),
				oFragment;

			oFragment = sap.ui.xmlfragment(oView.getId(), "fcg.sll.cmdtycd.manages1.view.fragment.FormsInPopover", that);

			return oFragment;
		}
	};
});