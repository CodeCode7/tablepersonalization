/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(function(Object) {
	"use strict";
	/**
	 * Business Constants
	 *
	 * @enum {string}
	 * @public
	 * @alias fcg.sll.cmdtycd.manages1.controller.BusinessContant
	 */
	var BusinessConstant = {
		/**
		 * Numbering Scheme Content is provided by data provider
		 * @public
		 */
		DataProvider: "A",
		
		/**
		 * Numbering Scheme Content is transferred from GTS
		 * @public
		 */
		GTS: "B",
		
		/**
		 * Numbering Scheme Content is created locally
		 * @public
		 */
		Local: ""
	};

	return BusinessConstant;

});