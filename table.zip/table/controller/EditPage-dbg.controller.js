/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
/* eslint-disable max-params */
sap.ui.define([
	"fcg/sll/cmdtycd/manages1/controller/DataModelController",
	"fcg/sll/cmdtycd/manages1/controller/Exception",
	"fcg/sll/cmdtycd/manages1/controller/ExceptionMessage",
	"fcg/sll/cmdtycd/manages1/controller/fragment/DialogSetValidityEndDate",
	"fcg/sll/cmdtycd/manages1/controller/MessagePopoverHelper",
	"fcg/sll/cmdtycd/manages1/controller/MessageBoxHelper",
	"fcg/sll/cmdtycd/manages1/model/formatter",
	"fcg/sll/cmdtycd/manages1/model/logger",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(
	DataModelController,
	Exception,
	ExceptionMessage,
	DialogSetValidityEndDate,
	MessagePopoverHelper,
	MessageBoxHelper,
	formatter,
	logger,
	JSONModel,
	Filter,
	FilterOperator
) {
	"use strict";

	return DataModelController.extend("fcg.sll.cmdtycd.manages1.controller.EditPage", $.extend({}, DialogSetValidityEndDate, {

		formatter: formatter,

		logger: logger,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var that = this,
				iOriginalBusyDelay,
				oViewModel;

			DataModelController.prototype.onInit.call(that);

			that._oTable = that.byId("tableEdit");
			sap.ui.getCore().getMessageManager().registerObject(that._oTable, true);

			oViewModel = new JSONModel({
				busy: true,
				delay: 0,
				table: {
					countCommodityCodes: 0,
					oListItemTemplate: that._oTable.getItems()[0].clone(this.getView().createId("CodeMasterItem"))
				}
			});

			that.getRouter().getRoute("editPage").attachPatternMatched(that._onObjectMatched, that);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = that.getView().getBusyIndicatorDelay();

			that.setModel(oViewModel, "editPageView");
			that.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			var oModel = that.getOwnerComponent().getModel(),
				aDeferredGroup = oModel.getDeferredGroups();
			that._sDummyGroupID = "DONOTSUBMIT";
			if (aDeferredGroup.indexOf(that._sDummyGroupID) === -1) {
				aDeferredGroup.push(that._sDummyGroupID);
				oModel.setDeferredGroups(aDeferredGroup);
			}

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when table update event is finished
		 * @param {sap.ui.base.Event} oEvent the table updateFinished event
		 * @public
		 */
		onUpdateFinished: function() {
			this.setBusyForView(false);
		},

		/**
		 * Event handler when set date button is pressed
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onPressSetValidityEndDate: function() {
			var that = this,
				oView = that.getView(),
				oDialog = oView.byId("dialogSetValidityEndDate");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "fcg.sll.cmdtycd.manages1.view.fragment.DialogSetValidityEndDate", that);
				var oContext = that.getView().getModel().createEntry("/C_CommodityCodeByLanguage", {
					groupId: that._sDummyGroupID
				});
				oDialog.setBindingContext(oContext);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}

			sap.ui.getCore().getMessageManager().registerObject(oDialog, true);
			oDialog.open();

		},

		/*
		 * overridden with edit page hasPendingChanges
		 * @name fcg.sll.cmdtycd.manages1.controller.EditPageController#hasPendingChanges
		 * @function
		 */
		hasPendingChanges: function() {
			var that = this,
				bChange = false;
			bChange = that.getModel().hasPendingChanges();
			sap.ushell.Container.setDirtyFlag(bChange);
			return bChange;
		},

		/*
		 * overridden with edit page getTable
		 * @name fcg.sll.cmdtycd.manages1.controller.EditPageController#getTable
		 * @function
		 * @returns {sap.ui.table.Table} table object
		 */
		getTable: function() {
			return this._oTable;
		},

		/*
		 * overridden with edit page setBusyForView
		 * @name fcg.sll.cmdtycd.manages1.controller.EditPageController#setBusyForView
		 * @function
		 */
		setBusyForView: function(bBusy) {
			var that = this;
			that.getModel("editPageView").setProperty("/busy", bBusy);
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var that = this,
				sOptionalQueryString = oEvent.getParameter("arguments")["?OptionalQueryString"],
				aCommodityCodes = that.getCommodityCodes(sOptionalQueryString),
				sTrdClassfctnNmbrSchmCntnt = that.getTrdClassfctnNmbrSchmCntnt(sOptionalQueryString),
				sLanguage = that.getLanguage(sOptionalQueryString);

			that._bInitialDataInconsistentCheck = true;
			MessagePopoverHelper.setCurrentView(this.getView());
			that.messagehelper.removeAllMessages();
			try {
				that._bindView(sTrdClassfctnNmbrSchmCntnt, sLanguage, aCommodityCodes);
			} catch (e) {
				logger.logException(e);
				that.onNavBack();
			}
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sTrdClassfctnNmbrSchmCntnt numbering scheme content
		 * @param {string} sLanguage language
		 * @param {array} aCommodityCodes Commodity Code
		 * @private
		 */
		_bindView: function(sTrdClassfctnNmbrSchmCntnt, sLanguage, aCommodityCodes) {
			var that = this;

			if (!sTrdClassfctnNmbrSchmCntnt) {
				throw new Exception(ExceptionMessage.NoTrdClassfctnNmbrSchmCntnt);
			}

			if (!sLanguage) {
				throw new Exception(ExceptionMessage.NoLanguage);
			}

			if (!aCommodityCodes || aCommodityCodes.length === 0) {
				throw new Exception(ExceptionMessage.NoCommodityCodes);
			}

			that.getModel().resetChanges();

			// Bind language text
			that.getModel().metadataLoaded().then(function() {
				var sLanguagePath = that.getModel().createKey("I_Language", {
					Language: sLanguage
				});
				that.byId("languageText").bindElement("/" + sLanguagePath);
			});

			// Count Commodity Code with selected items
			that.getModel("editPageView").setProperty("/table/countCommodityCodes", aCommodityCodes.length);

			// Bind table with selected items
			var oBindingInfo = {
				path: "/C_CommodityCodeByLanguage",
				template: that.getModel("editPageView").getProperty("/table/oListItemTemplate"),
				sorter: that.getSorters(),
				filters: that._createFilterForList(sTrdClassfctnNmbrSchmCntnt, sLanguage, aCommodityCodes),
				key: function(oContext) {
					return JSON.stringify(oContext.getObject());
				},
				events: {
					dataReceived: that._dataReceivedCommodityCodes.bind(that)
				}
			};

			that.getTable().bindElement({
				path: that.createPathForTrdClassfctnNmbrSchmCntnt(),
				events: {
					dataRequested: function() {
						that.setBusyForView(true);
					},
					dataReceived: function(oEvent) {
						that.setBusyForView(false);
					}
				}
			});
			that.getTable().bindItems(oBindingInfo);

		},

		_checkConsistencyCommodityCodes: function(aSelectedItems, aReceivedItems) {
			var that = this,
				aItem,
				sInconsistentItems = "";

			if (aSelectedItems.length !== aReceivedItems.length) {
				aSelectedItems.forEach(function(oSelectedItem) {
					aItem = aReceivedItems.filter(function(oReceivedItem) {
						return oSelectedItem.TrdClassfctnNmbrSchmCntnt === oReceivedItem.TrdClassfctnNmbrSchmCntnt &&
							oSelectedItem.CommodityCode === oReceivedItem.CommodityCode &&
							oSelectedItem.ValidityStartDate.getTime() === oReceivedItem.ValidityStartDate.getTime() &&
							oSelectedItem.Language === oReceivedItem.Language;
					});
					if (aItem.length === 0) {
						sInconsistentItems = sInconsistentItems + ", " + oSelectedItem.CommodityCode;
					}
				});
				that._showDataInconsistencyMessageBox(sInconsistentItems);
			}
		},

		_showDataInconsistencyMessageBox: function(sInconsistentItems) {
			var that = this,
				sMsgChoosenCommodityCodesAreDeleted = that.getResourceBundle().getText("msgChoosenCommodityCodesAreDeleted", sInconsistentItems.substr(
					2));

			MessageBoxHelper.showMessageBoxDataInconsistent(sMsgChoosenCommodityCodesAreDeleted, that);
		},

		/**
		 * Event handler when table update event is finished
		 * @param {sap.ui.base.Event} oEvent the table updateFinished event
		 * @public
		 */
		_dataReceivedCommodityCodes: function(oEvent) {
			var that = this,
				ODataModel = that.getModel(),
				aSelectedItems = that.getCommodityCodes(),
				aReceivedItems = oEvent.getParameter("data").results;

			if (that._bInitialDataInconsistentCheck) {
				that._bInitialDataInconsistentCheck = false;
				that._checkConsistencyCommodityCodes(aSelectedItems, aReceivedItems);
			} else {
				jQuery.each(ODataModel.getPendingChanges(), function(iIndex, oChange) {
					var sPath = null,
						aListItem;
					aListItem = that.getTable().getItems().filter(function(oItem) {
						return oChange.__metadata.uri.indexOf(oItem.getBindingContext().getPath()) > -1;
					});
					if (aListItem.length === 0) {
						logger.debug("[NOTFOUND] Step 3: Resolve model data inconsistance for pending changes");
						sPath = oChange.__metadata.uri;
						sPath = sPath.split("SLL_CMDTYCD_MANAGE").pop();
						sPath = sPath.replace(/[?](\w|\W)+/, "");
						ODataModel.resetChanges([
							sPath
						]);
					}
				});
			}
			that.getModel("editPageView").setProperty("/table/countCommodityCodes", aReceivedItems.length);
		},

		/**
		 * create filter for Commodity Code.
		 * @function
		 * @param {string} sTrdClassfctnNmbrSchmCntnt numbering scheme content
		 * @param {string} sLanguage language
		 * @param {array} aCommodityCodes Commodity Code
		 * @private
		 * @returns {sap.ui.model.Filter} Filter for Commodity Code
		 */
		_createFilterForList: function(sTrdClassfctnNmbrSchmCntnt, sLanguage, aCommodityCodes) {
			var aFilter = [];
			aCommodityCodes.forEach(function(oItem) {
				aFilter.push(
					new Filter([
						new Filter("CommodityCode", FilterOperator.EQ, oItem.CommodityCode),
						new Filter("ValidityStartDate", FilterOperator.EQ, oItem.ValidityStartDate)
					], true)
				);
			});
			return new Filter([
				new Filter("Language", FilterOperator.EQ, sLanguage),
				new Filter("TrdClassfctnNmbrSchmCntnt", FilterOperator.EQ, sTrdClassfctnNmbrSchmCntnt),
				new Filter(aFilter, false)
			], true);
		}
	}));
});