/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
/* Singleton pattern */
sap.ui.define([
	"sap/m/MessageBox"
], function(MessageBox) {
	"use strict";
	var bIsMessageBoxOpen = false;

	var MessageBoxHelper = {
		/**
		 * Show a {@link sap.m.MessageBox} for data loss warning
		 * @param {string} sMessage Message text
		 * @param {function} onPressOK Message box close event handler
		 * @param {controller} oController Controller for close event
		 * @function
		 * @public
		 */
		showMessageBoxDataLoss: function(sMessage, onPressOK, oController) {
			var that = this,
				oComponent = oController.getOwnerComponent();
			if (bIsMessageBoxOpen) {
				return;
			}
			that._setIsMessageBoxOpen(true);
			that._onPressOK = onPressOK;
			that._oController = oController;
			MessageBox.warning(
				sMessage, {
					id: oComponent.createId("warningMessageBoxDataLoss"),
					styleClass: oComponent.getContentDensityClass(),
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					onClose: that._onCloseMessageBox.bind(that)
				}
			);
		},

		/**
		 * Shows a {@link sap.m.MessageBox} when a service call has failed.
		 * Only the first error message will be display.
		 * @param {string} sMessage a technical error to be displayed on request
		 * @param {controller} oController Controller for close event
		 * @public
		 */
		showMessageBoxNotFound: function(sMessage, oController) {
			var that = this,
				oComponent = oController.getOwnerComponent();
			if (that._getIsMessageBoxOpen()) {
				return;
			}
			that._setIsMessageBoxOpen(true);
			MessageBox.error(
				sMessage, {
					id: oComponent.createId("notFoundMessageBox"),
					styleClass: oComponent.getContentDensityClass(),
					actions: [MessageBox.Action.CLOSE],
					onClose: function() {
						that._setIsMessageBoxOpen(false);
					}
				}
			);
		},

		/**
		 * Shows a {@link sap.m.MessageBox} when a service call has failed.
		 * Only the first error message will be display.
		 * @param {string} sMessage a technical error to be displayed on request
		 * @param {string} sDetails a technical error to be displayed on request
		 * @param {controller} oController Controller for close event
		 * @public
		 */
		showMessageBoxServiceError: function(sMessage, sDetails, oController) {
			var that = this,
				oComponent = oController.getOwnerComponent();
			if (that._getIsMessageBoxOpen()) {
				return;
			}
			that._setIsMessageBoxOpen(true);
			MessageBox.error(
				sMessage, {
					id: oComponent.createId("serviceErrorMessageBox"),
					details: sDetails,
					styleClass: oComponent.getContentDensityClass(),
					actions: [MessageBox.Action.CLOSE],
					onClose: function() {
						that._setIsMessageBoxOpen(false);
					}
				}
			);
		},

		/**
		 * Shows a {@link sap.m.MessageBox} when a service call has failed. Ask user to confirm if activate force update mode
		 * Ask user to confirm if activate force update mode
		 * @param {string} sMessage a technical error to be displayed on request
		 * @param {function} onPressOK Message box close event handler
		 * @param {controller} oController Controller for close event
		 * @public
		 */
		// showMessageBoxConfirmConcurrency: function(sMessage, onPressOK, oController) {
		// 	var that = this,
		// 		oComponent = oController.getOwnerComponent();
		// 	if (that._getIsMessageBoxOpen()) {
		// 		return;
		// 	}
		// 	that._setIsMessageBoxOpen(true);
		// 	that._onPressOK = onPressOK;
		// 	that._oController = oController;
		// 	MessageBox.confirm(
		// 		sMessage, {
		// 			id: oComponent.createId("confirmConcurrencyErrorMessageBox"),
		// 			styleClass: oComponent.getContentDensityClass(),
		// 			onClose: that._onCloseMessageBox.bind(that)
		// 		}
		// 	);
		// },

		/**
		 * Shows a {@link sap.m.MessageBox} when user update data in backend but not refresh data in frontend
		 * Info to user that there are inconsistent data in frontend
		 * @param {string} sMessage information of inconsistent data
		 * @param {controller} oController Controller for close event
		 * @public
		 */
		showMessageBoxDataInconsistent: function(sMessage, oController) {
			var that = this,
				oComponent = oController.getOwnerComponent();
			if (that._getIsMessageBoxOpen()) {
				return;
			}
			that._setIsMessageBoxOpen(true);
			MessageBox.information(
				sMessage, {
					id: oComponent.createId("dataInconsistentMessageBox"),
					styleClass: oComponent.getContentDensityClass(),
					actions: [MessageBox.Action.CLOSE],
					onClose: function() {
						that._setIsMessageBoxOpen(false);
					}
				}
			);
		},

		/**
		 * Show a {@link sap.m.MessageBox} for data volumn confirmation
		 * @param {string} sMessage Message text
		 * @param {function} onPressOK Message box close event handler
		 * @param {controller} oController Controller for close event
		 * @function
		 * @public
		 */
		showMessageBoxSelectLimitation: function(sMessage, onPressOK, oController) {
			var that = this,
				oComponent = oController.getOwnerComponent();
			if (that._getIsMessageBoxOpen()) {
				return;
			}
			that._setIsMessageBoxOpen(true);
			that._onPressOK = onPressOK;
			that._oController = oController;
			MessageBox.confirm(
				sMessage, {
					id: oComponent.createId("informationDataVolumnMessageBox"),
					styleClass: oComponent.getContentDensityClass(),
					onClose: that._onCloseMessageBox.bind(that)
				}
			);
		},

		/**
		 * Show a {@link sap.m.MessageBox} for delete confirmation
		 * @param {string} sId Message Box Id
		 * @param {string} sMessage Message text
		 * @param {function} onPressDelete Message box close event handler
		 * @param {controller} oController Controller for close event
		 * @function
		 * @public
		 */
		showMessageBoxConfirmDeletion: function(sId, sMessage, onPressDelete, oController) {
			var that = this,
				oComponent = oController.getOwnerComponent();
			if (that._getIsMessageBoxOpen()) {
				return;
			}
			that._setIsMessageBoxOpen(true);
			that._onPressDelete = onPressDelete;
			that._oController = oController;
			MessageBox.confirm(
				sMessage, {
					id: oComponent.createId(sId),
					actions: [MessageBox.Action.DELETE, MessageBox.Action.CANCEL],
					styleClass: oComponent.getContentDensityClass(),
					onClose: that._onCloseMessageBox.bind(that)
				}
			);
		},

		_setIsMessageBoxOpen: function(bOpen) {
			bIsMessageBoxOpen = bOpen;
		},

		_getIsMessageBoxOpen: function() {
			return bIsMessageBoxOpen;
		},

		_onCloseMessageBox: function(sAction) {
			var that = this;
			that._setIsMessageBoxOpen(false);
			switch (sAction) {
				case MessageBox.Action.OK:
					that._onPressOK.apply(that._oController, arguments);
					break;
				case MessageBox.Action.DELETE:
					that._onPressDelete.apply(that._oController, arguments);
					break;
				default:
					break;
			}
		}
	};
	return MessageBoxHelper;
});