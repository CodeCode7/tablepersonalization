/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/base/Object",
	"fcg/sll/cmdtycd/manages1/controller/Exception",
	"fcg/sll/cmdtycd/manages1/controller/ExceptionMessage",
	"fcg/sll/cmdtycd/manages1/controller/MessagePopoverHelper",
	"fcg/sll/cmdtycd/manages1/controller/MessageBoxHelper",
	"fcg/sll/cmdtycd/manages1/model/logger",
	"fcg/sll/cmdtycd/manages1/model/messagehelper"
], function (UI5Object, Exception, ExceptionMessage, MessagePopoverHelper, MessageBoxHelper, logger, messagehelper) {
	"use strict";

	return UI5Object.extend("fcg.sll.cmdtycd.manages1.controller.ErrorHandler", {

		logger: logger,

		messagehelper: messagehelper,

		serverErrorCategory: {
			// ServerConcurrencyConflict: "ServerConcurrencyConflict",
			ServerInternalErrorCanBeResolved: "ServerInternalErrorCanBeResolved",
			ServerResourceNotFound: "ServerResourceNotFound",
			ServerResourceLocked: "ServerResourceLocked",
			ServerBadRequest: "ServerBadRequest"
		},

		/**
		 * Handles application errors by automatically attaching to the model events and displaying errors when needed.
		 * @class
		 * @param {sap.ui.core.UIComponent} oComponent reference to the app's component
		 * @public
		 * @alias fcg.sll.cmdtycd.manages1.controller.ErrorHandler
		 */
		constructor: function (oComponent) {
			var that = this;
			that._oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
			that._oComponent = oComponent;
			that._oModel = oComponent.getModel();
			// that._aConfirmConcurrencyUrl = [];
			that._sErrorText = that._oResourceBundle.getText("errorText");
			that._oModel.attachMetadataFailed(that._onMetadataFailed, that);
			that._oModel.attachRequestFailed(that._onRequestFailed, that);
		},

		getOwnerComponent: function () {
			return this._oComponent;
		},

		_onMetadataFailed: function (oEvent) {
			var that = this,
				oParams = oEvent.getParameters();
			MessageBoxHelper.showMessageBoxServiceError(that._sErrorText, oParams.response, that);
		},

		_onRequestFailed: function (oEvent) {
			var that = this,
				oParams = oEvent.getParameters();
			// url = oParams.url.replace(/[?](\w|\W)+/, "");
			if (oParams.url.indexOf("C_CommodityCodeByLanguage") === 0 &&
				that._statusCodeCategory(oParams) === that.serverErrorCategory.ServerInternalErrorCanBeResolved) {

				// Internal error handled by inline value status & message popover, Eat the response call back 
				MessagePopoverHelper.setDisableMessagePopover(true);

			} else if (oParams.url.indexOf("C_CommodityCodeByLanguage") === 0 &&
				that._statusCodeCategory(oParams) === that.serverErrorCategory.ServerResourceNotFound &&
				(oParams.method === "MERGE" || oParams.method === "PUT" || oParams.method === "DELETE" || oParams.method === "GET")) {
				MessageBoxHelper.showMessageBoxNotFound(
					that._oResourceBundle.getText("errorCommodityCodesNotFound"),
					that
				);
				// Handle not found, Eat the response call back 
				MessagePopoverHelper.setDisableMessagePopover(true);
				messagehelper.resetServerMessages();
				that._bRefreshModelForNotFound = true;
				logger.debug("[NOTFOUND] Step 1: Refresh Model For NotFound Determinded");

			}
			// else if (oParams.url.indexOf("C_CommodityCodeByLanguage") === 0 &&
			// 	that._statusCodeCategory(oParams) === that.serverErrorCategory.ServerConcurrencyConflict) {

			// 	MessageBoxHelper.showMessageBoxConfirmConcurrency(
			// 		that._oResourceBundle.getText("errorConcurrencyConflict"),
			// 		that._onPresswConfirmConcurrency,
			// 		that
			// 	);
			// 	that._aConfirmConcurrencyUrl.push(url);
			// } 
			else if (oParams.url.indexOf("C_CommodityCodeByLanguage") === 0 &&
				that._statusCodeCategory(oParams) === that.serverErrorCategory.ServerResourceLocked) {

				MessageBoxHelper.showMessageBoxServiceError(
					that._oResourceBundle.getText("errorResourceLocked"),
					oParams.response,
					that
				);

			} else if (oParams.url.indexOf("C_CommodityCodeByLanguage") === 0 &&
				that._statusCodeCategory(oParams) === that.serverErrorCategory.ServerBadRequest) {

				MessageBoxHelper.showMessageBoxServiceError(that._sErrorText, oParams.response, that);

			} else if (oParams.url.indexOf("TrdClassfctnNmbrSchmCntntActnCtrlSet") === 0 &&
				that._statusCodeCategory(oParams) === that.serverErrorCategory.ServerResourceNotFound &&
				oParams.method === "GET") {

				// Internal error handled by inline value status & message popover, Eat the response call back 
				MessagePopoverHelper.setDisableMessagePopover(true);
				messagehelper.resetServerMessages();

			} else {

				MessageBoxHelper.showMessageBoxServiceError(that._sErrorText, oParams.response, that);

			}
		},

		// _onPresswConfirmConcurrency: function(oAction) {
		// 	var that = this;
		// 	that._aConfirmConcurrencyUrl.forEach(function(url) {
		// 		that._oModel.forceEntityUpdate(url);
		// 	});
		// 	that._aConfirmConcurrencyUrl = [];
		// 	that.getOwnerComponent().triggerLastChange();
		// },

		_statusCodeCategory: function (oParams) {
			var that = this;
			switch (oParams.response.statusCode) {
			case 400:
			case "400":
				return that.serverErrorCategory.ServerInternalErrorCanBeResolved;
			case 404:
			case "404":
				return that.serverErrorCategory.ServerResourceNotFound;
				// case 412:
				// case "412":
				// 	return that.serverErrorCategory.ServerConcurrencyConflict;
			case 423:
			case "423":
				return that.serverErrorCategory.ServerResourceLocked;
			case 500:
			case "500":
				return that.serverErrorCategory.ServerBadRequest;
			default:
				return that.serverErrorCategory.ServerBadRequest;
			}
		}
	});
});