/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"fcg/sll/cmdtycd/manages1/controller/MessagePopoverHelper",
	"fcg/sll/cmdtycd/manages1/model/formatter",
	"fcg/sll/cmdtycd/manages1/model/logger",
	"fcg/sll/cmdtycd/manages1/model/messagehelper"
], function(Controller, History, MessagePopoverHelper, formatter, logger, messagehelper) {
	"use strict";

	return Controller.extend("fcg.sll.cmdtycd.manages1.controller.BaseController", $.extend({}, MessagePopoverHelper.getEventHandlerForMessagesIndicator(), {

		messagehelper: messagehelper,

		formatter: formatter,

		logger: logger,

		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Getter for the ErrorHandler.
		 * @public
		 * @returns {fcg.sll.cmdtycd.manages1.controller.ErrorHandler} the ErrorHandler of the component
		 */
		getErrorHandler: function() {
			return this.getOwnerComponent().getErrorHandler();
		},

		/**
		 * Navigate back to previous screen
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @function
		 * @public
		 */
		navBackOnHistory: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			messagehelper.removeAllMessages();
			sap.ushell.Container.setDirtyFlag(false);
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist");
			}
		},

		/*
		 * Set dirty flag for side effect
		 * @name fcg.sll.cmdtycd.manages1.controller.BaseController#setDirtyFlag
		 * @function
		 */
		setDirtyFlag: function() {
			var that = this,
				oSelectedItemsModel = that.getOwnerComponent().getModel("selectedItems"),
				sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				oSelectedItemsModel.setProperty("/DirtyFlag", true);
			}
		},

		/*
		 * Set model refresh flag for dirty status
		 * @name fcg.sll.cmdtycd.manages1.controller.BaseController#getRefreshModelForNotFound
		 * @function
		 */
		getRefreshModelForNotFound: function() {
			return this.getErrorHandler()._bRefreshModelForNotFound;
		},

		/*
		 * Reset model refresh flag for dirty status
		 * @name fcg.sll.cmdtycd.manages1.controller.BaseController#resetRefreshModelForNotFound
		 * @function
		 */
		resetRefreshModelForNotFound: function() {
			this.getErrorHandler()._bRefreshModelForNotFound = false;
		},

		onPressEmailAction: function() {
			sap.m.URLHelper.triggerEmail(null, this.getResourceBundle().getText("appTitle"), document.URL);
		}

	}));

});