/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"fcg/sll/cmdtycd/manages1/controller/BaseController",
	"fcg/sll/cmdtycd/manages1/controller/Exception",
	"fcg/sll/cmdtycd/manages1/controller/ExceptionMessage",
	"fcg/sll/cmdtycd/manages1/controller/MessagePopoverHelper",
	"fcg/sll/cmdtycd/manages1/controller/MessageBoxHelper",
	"fcg/sll/cmdtycd/manages1/model/logger",
	"sap/ui/model/ChangeReason",
	"sap/m/MessageToast"
], function(BaseController, Exception, ExceptionMessage, MessagePopoverHelper, MessageBoxHelper, logger, ChangeReason,
	MessageToast) {
	"use strict";

	return BaseController.extend("fcg.sll.cmdtycd.manages1.controller.DataModelController", {

		logger: logger,

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var that = this;
			that._oMessagesIndicator = that.byId("messagesIndicator");
			that._oSaveButton = that.byId("btnSave");
			MessagePopoverHelper.attachAfterRenderForMessagesIndicator(that._oMessagesIndicator, that);
			that.getOwnerComponent().getModel().attachPropertyChange(that.onPropertyChange, that);
		},

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function() {
			var that = this;
			if (that.hasPendingChanges()) {
				that.showMessageBoxDataLoss();
			} else {
				that._unbindTableItems();
				that.navBackOnHistory();
			}
		},

		/**
		 * Event handler when save button is pressed
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onPressSaveBtn: function(oEvent) {
			var that = this,
				mParameters,
				iSavedItemsCount = 0;

			// Fix errors on screen to make data consistence
			if (that.messagehelper.hasClientValidationError()) {
				return;
			}

			// Check if model is changed
			if (that.hasPendingChanges()) {
				// Remove empty items before submit changes
				if (typeof that.removeEmptyItems === "function") {
					that.removeEmptyItems();
				}
				that.messagehelper.resetServerMessages();
				MessagePopoverHelper.getMessagePopover().close();
				// Submit changes
				that.setBusyForView(true);
				mParameters = {
					success: function(oEvt) {
						that.setBusyForView(false);
						// Refresh model incase resource is deleted
						if (that.getRefreshModelForNotFound()) {
							logger.debug("[NOTFOUND] Step 2: Refresh Model Started");
							that.resetRefreshModelForNotFound();
							that.getOwnerComponent().getModel().refresh();
							return;
						}
						if (that.messagehelper.hasErrorMessage()) {
							return;
						}
						that.setDirtyFlag();
						that._unbindTableItems();
						iSavedItemsCount = oEvt.__batchResponses[0].__changeResponses.length;
						that._showSaveSuccessInfo(iSavedItemsCount);
						that.navBackOnHistory();
					},
					error: function(oEvt) {
						that.setBusyForView(false);
					}
				};
				that.getModel().submitChanges(mParameters);
				// that.getOwnerComponent().setControllerActivityForLastChange(that, "Change");
			} else {
				that.messagehelper.resetServerMessages();
				that._showSaveSuccessInfo(0);
				that.navBackOnHistory();
			}
		},

		/**
		 * Event handler when cancel button is pressed
		 * @param {sap.ui.base.Event} oEvent the button press event
		 * @public
		 */
		onPressCancelBtn: function() {
			this.onNavBack();
		},

		/**
		 * Event handler when model property is changed
		 * @param {sap.ui.base.Event} oEvent the oDataModel propertyChange event
		 * @public
		 */
		onPropertyChange: function(oEvent) {
			var that = this,
				mParameters = oEvent.getParameters();

			if (mParameters.reason === ChangeReason.Binding) {

				// Update Model Change
				that.hasPendingChanges();
			}
		},

		/**
		 * Event handler when date validation is Success
		 * @param {sap.ui.base.Event} oEvent the field dateValidationSuccess event
		 * @public
		 */
		onDateValidationSuccess: function(oEvent) {
			// Validation success
		},

		/**
		 * Show data loss message
		 * @function
		 * @public
		 */
		showMessageBoxDataLoss: function() {
			var that = this,
				oBundle = that.getResourceBundle(),
				sMessage = oBundle.getText("msgDataLoss");
			MessageBoxHelper.showMessageBoxDataLoss(sMessage, that._onPressOK, that);
		},

		/**
		 * Validation of item pending date
		 * @param {sap.m.ColumnListItem} oListItem object
		 * @public
		 * @returns {boolean} yes or no
		 */
		hasLineItemPendingDateError: function(oListItem) {
			var that = this,
				oDatePickerValidityStartDate = that._getControlFromListItem(oListItem, "ValidityStartDate"),
				oDatePickerValidityEndDate = that._getControlFromListItem(oListItem, "ValidityEndDate");
			return oDatePickerValidityStartDate.getValueState() === "Error" || oDatePickerValidityEndDate.getValueState() === "Error";
		},

		/*
		 * overridden to prevent instantiation of Template
		 * @name fcg.sll.cmdtycd.manages1.controller.DataModelController#hasPendingChanges
		 * @function
		 */
		hasPendingChanges: function() {
			throw new Exception(ExceptionMessage.getMessageFunctionNotImplemented("hasPendingChanges"));
		},

		/*
		 * overridden to prevent instantiation of Template
		 * @name fcg.sll.cmdtycd.manages1.controller.DataModelController#getTable
		 * @function
		 */
		getTable: function() {
			throw new Exception(ExceptionMessage.getMessageFunctionNotImplemented("getTable"));
		},

		/*
		 * Get language from Uri or from cached model
		 * @name fcg.sll.cmdtycd.manages1.controller.DataModelController#getLanguage
		 * @function
		 * @param {string} optional query string from url
		 * @returns {string} language
		 */
		getLanguage: function(sOptionalQueryString) {
			var that = this,
				sLanguage,
				oSelectedItemsModel = that.getOwnerComponent().getModel("selectedItems");
			if (sOptionalQueryString) {
				sLanguage = sOptionalQueryString.Language ||
					oSelectedItemsModel.getProperty("/Language");
			} else {
				sLanguage = oSelectedItemsModel.getProperty("/Language");
			}
			oSelectedItemsModel.setProperty("/Language", sLanguage);
			return sLanguage;
		},

		/*
		 * Get numbering scheme content from Uri or from cached model
		 * @name fcg.sll.cmdtycd.manages1.controller.DataModelController#getTrdClassfctnNmbrSchmCntnt
		 * @function
		 * @param {string} optional query string from url
		 * @returns {string} numbering scheme content
		 */
		getTrdClassfctnNmbrSchmCntnt: function(sOptionalQueryString) {
			var that = this,
				sTrdClassfctnNmbrSchmCntnt,
				oSelectedItemsModel = that.getOwnerComponent().getModel("selectedItems");
			if (sOptionalQueryString) {
				sTrdClassfctnNmbrSchmCntnt = sOptionalQueryString.TrdClassfctnNmbrSchmCntnt ||
					oSelectedItemsModel.getProperty("/TrdClassfctnNmbrSchmCntnt");
			} else {
				sTrdClassfctnNmbrSchmCntnt = oSelectedItemsModel.getProperty("/TrdClassfctnNmbrSchmCntnt");
			}
			oSelectedItemsModel.setProperty("/TrdClassfctnNmbrSchmCntnt", sTrdClassfctnNmbrSchmCntnt);
			return sTrdClassfctnNmbrSchmCntnt;
		},

		/*
		 * Get Commodity Code from Uri or from cached model
		 * @name fcg.sll.cmdtycd.manages1.controller.DataModelController#getCommodityCodes
		 * @function
		 * @param {string} optional query string from url
		 * @returns {array} Commodity Code
		 */
		getCommodityCodes: function(sOptionalQueryString) {
			var that = this,
				aCommodityCodes,
				oSelectedItemsModel = that.getOwnerComponent().getModel("selectedItems");
			if (sOptionalQueryString && sOptionalQueryString.CommodityCodes) {
				aCommodityCodes = JSON.parse(sOptionalQueryString.CommodityCodes);
				aCommodityCodes.forEach(function(oCommodityCode) {
					oCommodityCode.ValidityStartDate = new Date(oCommodityCode.ValidityStartDate);
				});
			} else {
				aCommodityCodes = oSelectedItemsModel.getProperty("/CommodityCodes");
			}
			oSelectedItemsModel.setProperty("/CommodityCodes", aCommodityCodes);
			return aCommodityCodes;
		},

		/*
		 * Get sorters from cached model
		 * @name fcg.sll.cmdtycd.manages1.controller.DataModelController#getSorters
		 * @function
		 * @returns {array} sorters
		 */
		getSorters: function() {
			var that = this,
				oSelectedItemsModel = that.getOwnerComponent().getModel("selectedItems");
			return oSelectedItemsModel.getProperty("/Sorters");
		},

		/*
		 * overridden to prevent instantiation of Template
		 * @name fcg.sll.cmdtycd.manages1.controller.DataModelController#setBusyForView
		 * @function
		 */
		setBusyForView: function(bBusy) {
			throw new Exception(ExceptionMessage.getMessageFunctionNotImplemented("setBusyForView"));
		},

		firePressForSaveButton: function() {
			var that = this;
			that._oSaveButton.firePress();
		},

		/**
		 * Create the path for numbering scheme content
		 * @private
		 * @returns {string} path for numbering cheme content
		 */
		createPathForTrdClassfctnNmbrSchmCntnt: function() {
			var that = this,
				sTrdClassfctnNmbrSchmCntnt = that.getTrdClassfctnNmbrSchmCntnt(),
				sPath = "TrdClassfctnNmbrSchmCntntActnCtrlSet";
			sPath = "/" + that.getModel().createKey(sPath, {
				TrdClassfctnNmbrSchmCntnt: sTrdClassfctnNmbrSchmCntnt
			});
			return sPath;
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Function information after saveing successfully
		 * @param {int} iCount success change response count
		 * @function
		 */
		_showSaveSuccessInfo: function(iCount) {
			var that = this;
			MessageToast.show(
				that.getResourceBundle().getText("msgSaving", [iCount]), {
					closeOnBrowserNavigation: false
				}
			);
		},

		_getControlFromListItem: function(oListItem, sPropertyName) {
			var aCells;
			aCells = oListItem.getCells().filter(function(oControl) {
				try {
					var oBinding = oControl.getBinding("value") || oControl.getBinding("text");
					if (oBinding && oBinding.getPath() === sPropertyName) {
						return true;
					}
				} catch (e) {
					// Exception
				}
				return false;
			});
			return aCells[0];
		},

		_unbindTableItems: function() {
			var that = this;
			if (typeof that.getTable === "function") {
				that.getTable().unbindItems();
			}
		},

		_onPressOK: function(sAction) {
			var that = this;
			that.getModel().resetChanges();
			that._unbindTableItems();
			that.navBackOnHistory();
		}

	});

});