/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(function(Object) {
	"use strict";
	/**
	 * Business Constants
	 *
	 * @enum {string}
	 * @public
	 * @alias fcg.sll.cmdtycd.manages1.controller.BusinessContant
	 */
	var TechnicalConstant = {
		/**
		 * Commodity Code entity set
		 * @public
		 */
		CommodityCodeSet: "C_CommodityCodeByLanguage",
		
		/**
		 * Language entity set
		 * @public
		 */
		LanguageSet: "I_Language",
		
		/**
		 * Numbering Scheme Content entity set
		 * @public
		 */
		CmmdtyCodeNmbrSchmCntnt: "TrdClassfctnNmbrSchmCntntActnCtrlSet"
	};

	return TechnicalConstant;

});