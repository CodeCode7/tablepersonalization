/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"fcg/sll/cmdtycd/manages1/localService/TechnicalConstant"
], function(Object, JSONModel, TechnicalConstant) {

	"user strict";

	/**
	 * Mock server error handler class
	 *
	 * return the mock server errors by URL requested
	 * defined constraints for a type.
	 * @param {jQuery.sap.getUriParameters} oUriParameters uri parameters
	 * @param {String} sJsonFilesUrl json file url of mock errors
	 * @alias fcg.sll.cmdtycd.manages1.localService.mockrequest
	 * @public
	 */
	return Object.extend("fcg.sll.cmdtycd.manages1.localService.mockrequest", {
		constructor: function(oUriParameters, sJsonFilesUrl, oMockServer) {
			this._oUriParameters = oUriParameters;
			this._sMockErrorFilesUrl = sJsonFilesUrl + "/mockError.json";
			this._oMockServer = oMockServer;
		},

		/**
		 * call each event handlers to handle every request error.
		 * @param {array} aRequests requests
		 * @public
		 */
		onErrorRequestHandler: function(aRequests) {
			var that = this;
			// handling the metadata error test
			that.onMetadataError(aRequests);

			// Handling request errors
			that.onRequestError(aRequests);

			// Handling request errors for Language
			that.onRequestErrorForLanguage(aRequests);

			// Handling request which response empty Language
			that.onRequestEmptyLanguage(aRequests);

			// Handling request errors for Numbering Scheme Content value help
			that.onRequestErrorForTrdClassfctnNmbrSchmCntntVH(aRequests);

			// Handling request errors for Numbering Scheme Content
			that.onRequestErrorForTrdClassfctnNmbrSchmCntnt(aRequests);

			// Handling request errors for submit changes
			that.onRequestErrorForSumbitChanges(aRequests);

			// Handling request errors for Concurrency Conflict
			// that.onRequestErrorForConcurrencyConflict(aRequests);

			// Handling request errors for Lock Conflict
			that.onRequestErrorForLockConflict(aRequests);

			// Handling request errors for not found
			that.onRequestErrorForNotFound(aRequests);

			// Handling request errors for Technical Reason
			that.onRequestErrorForTechnicalReason(aRequests);
		},

		/**
		 * handle metadata request error.
		 * @param {array} aRequests requests
		 * @public
		 */
		onMetadataError: function(aRequests) {
			var that = this,
				bMetadataError = that._oUriParameters.get("metadataError");
			if (bMetadataError) {
				jQuery.sap.log.warning("Handle metadata error");
				aRequests.forEach(function(aEntry) {
					if (aEntry.path.toString().indexOf("$metadata") > -1) {
						that._fnResponse(500, "metadata Error", aEntry);
					}
				});
			}
		},

		/**
		 * handle bad request error and edit request error.
		 * @param {array} aRequests requests
		 * @public
		 */
		onRequestError: function(aRequests) {
			var that = this,
				oUriParameters = that._oUriParameters,
				sErrorParam = oUriParameters.get("errorType"),
				iErrorCode = !this.sErrorParam ? 500 : 400;
			if (sErrorParam) {
				jQuery.sap.log.warning("Handle request error");
				aRequests.forEach(function(aEntry) {
					if (aEntry.path.toString().indexOf(TechnicalConstant.CommodityCodeSet) > -1) {
						that._fnResponse(iErrorCode, sErrorParam, aEntry);
					}
				});
			}
		},

		/**
		 * handle language request error.
		 * @param {array} aRequests requests
		 * @public
		 */
		onRequestErrorForLanguage: function(aRequests) {
			var that = this,
				sErrorLanguage = that._oUriParameters.get("errorLanguage"),
				iErrorCodeLanguage = !sErrorLanguage ? 500 : 404;
			if (sErrorLanguage) {
				jQuery.sap.log.warning("Handle language set error");
				aRequests.forEach(function(aEntry) {
					if (aEntry.path.toString().indexOf(TechnicalConstant.LanguageSet) > -1) {
						that._fnResponse(iErrorCodeLanguage, sErrorLanguage, aEntry);
					}
				});
			}
		},

		/**
		 * handle request response empty language.
		 * @param {array} aRequests requests
		 * @public
		 */
		onRequestEmptyLanguage: function(aRequests) {
			var that = this,
				sErrorLanguageEmpty = that._oUriParameters.get("errorLanguageEmpty");
			if (sErrorLanguageEmpty) {
				jQuery.sap.log.warning("Handle language empty");
				aRequests.forEach(function(aEntry) {
					if (aEntry.path.toString().indexOf(TechnicalConstant.LanguageSet) > -1 && aEntry.method === "GET") {
						that._fnResponseEmpty(aEntry);
					}
				});
			}
		},

		/**
		 * handle numbering scheme content value help request error.
		 * @param {array} aRequests requests
		 * @public
		 */
		onRequestErrorForTrdClassfctnNmbrSchmCntntVH: function(aRequests) {
			var that = this,
				sErrorNumberingSchemeContentValueHelp = that._oUriParameters.get("errorNumberingSchemeContentValueHelp"),
				iErrorCodeTrdClassfctnNmbrSchmCntnt = !sErrorNumberingSchemeContentValueHelp ? 500 : 404;
			if (sErrorNumberingSchemeContentValueHelp) {
				jQuery.sap.log.warning("Handle numbering scheme content value help empty");
				aRequests.forEach(function(aEntry) {
					if (aEntry.path.toString().indexOf(TechnicalConstant.CmmdtyCodeNmbrSchmCntnt) > -1) {
						that._fnResponse(iErrorCodeTrdClassfctnNmbrSchmCntnt, sErrorNumberingSchemeContentValueHelp, aEntry);
					}
				});
			}
		},

		/**
		 * handle numbering scheme content request error
		 * @param {array} aRequests requests
		 * @public
		 */
		onRequestErrorForTrdClassfctnNmbrSchmCntnt: function(aRequests) {
			var that = this,
				sErrorNumberingSchemeContentSource = that._oUriParameters.get("errorNumberingSchemeContentSource"),
				iErrorCodeTrdClassfctnNmbrSchmCntnt = !sErrorNumberingSchemeContentSource ? 500 : 404;
			if (sErrorNumberingSchemeContentSource) {
				jQuery.sap.log.warning("Handle numbering scheme content customizing not available");
				aRequests.forEach(function(aEntry) {
					if (aEntry.path.toString().indexOf(TechnicalConstant.CmmdtyCodeNmbrSchmCntnt) > -1) {
						that._fnResponse(iErrorCodeTrdClassfctnNmbrSchmCntnt, sErrorNumberingSchemeContentSource, aEntry);
					}
				});
			}
		},

		/**
		 * handle bad request for edit error.
		 * @param {array} aRequests requests
		 * @public
		 */
		onRequestErrorForSumbitChanges: function(aRequests) {
			var that = this,
				oMockErrorJSON = new JSONModel(),
				aMockRequests = [],
				oMockRequest,
				sErrorForSubmit = that._oUriParameters.get("errorForSubmit");

			jQuery.sap.log.warning("Handle  submit changes request error");
			oMockErrorJSON.loadData(that._sMockErrorFilesUrl, {}, false);
			aMockRequests = oMockErrorJSON.getObject("/");

			switch (sErrorForSubmit) {
				case "errorEditPageValidTo":
					aRequests.forEach(function(oEntry) {
						oMockRequest = aMockRequests.filter(
							function(e) {
								return oEntry.path.toString().indexOf(e.pathPatternKeyWord) > -1 &&
									oEntry.method === e.method &&
									e.errorType === "errorEditPageValidTo" &&
									TechnicalConstant.CommodityCodeSet === e.pathPatternKeyWord;
							})[0];
						if (oMockRequest) {
							that._fnResponseJSON(400, oMockRequest.responseBody, oEntry);
						}
					});
					break;
				case "errorEditPageValidFrom":
					aRequests.forEach(function(oEntry) {
						oMockRequest = aMockRequests.filter(
							function(e) {
								return oEntry.path.toString().indexOf(e.pathPatternKeyWord) > -1 &&
									oEntry.method === e.method &&
									e.errorType === "errorEditPageValidFrom" &&
									TechnicalConstant.CommodityCodeSet === e.pathPatternKeyWord;
							})[0];
						if (oMockRequest) {
							that._fnResponseJSON(400, oMockRequest.responseBody, oEntry);
						}
					});
					break;
				case "errorDeleteEntity":
					aRequests.forEach(function(oEntry) {
						oMockRequest = aMockRequests.filter(
							function(e) {
								return oEntry.path.toString().indexOf(e.pathPatternKeyWord) > -1 &&
									oEntry.method === e.method &&
									e.errorType === "errorDeleteEntity" &&
									TechnicalConstant.CommodityCodeSet === e.pathPatternKeyWord;
							})[0];
						if (oMockRequest) {
							that._fnResponseJSON(400, oMockRequest.responseBody, oEntry);
						}
					});
					break;
				case "errorCreateEntity":
					aRequests.forEach(function(oEntry) {
						oMockRequest = aMockRequests.filter(
							function(e) {
								return oEntry.path.toString().indexOf(e.pathPatternKeyWord) > -1 &&
									oEntry.method === e.method &&
									e.errorType === "errorCreateEntity" &&
									TechnicalConstant.CommodityCodeSet === e.pathPatternKeyWord;
							})[0];
						if (oMockRequest) {
							that._fnResponseJSON(400, oMockRequest.responseBody, oEntry);
						}
					});
					break;
			}
		},

		// onRequestErrorForConcurrencyConflict: function(aRequests) {
		// 	var that = this,
		// 		oMockErrorJSON = new JSONModel(),
		// 		aMockRequests = [],
		// 		oMockRequest,
		// 		sErrorConcurrencyConflict = that._oUriParameters.get("errorConcurrencyConflict");
		// 	if (sErrorConcurrencyConflict) {
		// 		jQuery.sap.log.warning("Handle concurrency conflict request error");
		// 		oMockErrorJSON.loadData(that._sMockErrorFilesUrl, {}, false);
		// 		aMockRequests = oMockErrorJSON.getObject("/");
		// 		aRequests.forEach(function(oEntry) {
		// 			oMockRequest = aMockRequests.filter(
		// 				function(e) {
		// 					return oEntry.path.toString().indexOf(e.pathPatternKeyWord) > -1 &&
		// 						oEntry.method === e.method &&
		// 						e.errorType === "errorConcurrencyConflict" &&
		// 						TechnicalConstant.CommodityCodeSet === e.pathPatternKeyWord;
		// 				})[0];
		// 			if (oMockRequest) {
		// 				that._fnResponseConcurrencyConflict(oMockRequest.responseBody, oEntry);
		// 			}
		// 		});
		// 	}
		// },

		onRequestErrorForLockConflict: function(aRequests) {
			var that = this,
				oMockErrorJSON = new JSONModel(),
				aMockRequests = [],
				oMockRequest,
				sErrorLockConflict = that._oUriParameters.get("errorLockConflict");
			if (sErrorLockConflict) {
				jQuery.sap.log.warning("Handle lock conflict error");
				oMockErrorJSON.loadData(that._sMockErrorFilesUrl, {}, false);
				aMockRequests = oMockErrorJSON.getObject("/");
				aRequests.forEach(function(oEntry) {
					oMockRequest = aMockRequests.filter(
						function(e) {
							return oEntry.path.toString().indexOf(e.pathPatternKeyWord) > -1 &&
								oEntry.method === e.method &&
								e.errorType === "errorLockConflict" &&
								TechnicalConstant.CommodityCodeSet === e.pathPatternKeyWord;
						})[0];
					if (oMockRequest) {
						that._fnResponseJSON(423, oMockRequest.responseBody, oEntry);
					}
				});
			}
		},

		onRequestErrorForNotFound: function(aRequests) {
			var that = this,
				oMockErrorJSON = new JSONModel(),
				aMockRequests = [],
				oMockRequest,
				sErrorCommodityCodeNotFound = that._oUriParameters.get("errorCommodityCodeNotFound");
			if (sErrorCommodityCodeNotFound) {
				jQuery.sap.log.warning("Handle lock conflict error");
				oMockErrorJSON.loadData(that._sMockErrorFilesUrl, {}, false);
				aMockRequests = oMockErrorJSON.getObject("/");
				aRequests.forEach(function(oEntry) {
					oMockRequest = aMockRequests.filter(
						function(e) {
							return oEntry.path.toString().indexOf(e.pathPatternKeyWord) > -1 &&
								(oEntry.method === "MERGE" || oEntry.method === "DELETE") &&
								e.method === "MERGE" &&
								e.errorType === "errorCommodityCodeNotFound" &&
								e.pathPatternKeyWord === TechnicalConstant.CommodityCodeSet;
						})[0];
					if (oMockRequest) {
						that._fnResponseCommodityCodeNotFound(oMockRequest.responseBody, oEntry);
					}
				});
				// EntitySet data will be recovered incase request fail, hence remove this after first query
				aRequests.forEach(function(oEntry) {
					oMockRequest = aMockRequests.filter(
						function(e) {
							return oEntry.path.toString().indexOf(e.pathPatternKeyWord) > -1 &&
								oEntry.method === "GET" &&
								e.method === "MERGE" &&
								e.errorType === "errorCommodityCodeNotFound" &&
								e.pathPatternKeyWord === TechnicalConstant.CommodityCodeSet;
						})[0];
					if (oMockRequest) {
						that._fnResponseCommodityCodeGET(oEntry);
					}
				});
			}
		},

		onRequestErrorForTechnicalReason: function(aRequests) {
			var that = this,
				oMockErrorJSON = new JSONModel(),
				aMockRequests = [],
				oMockRequest,
				sErrorTechnicalReason = that._oUriParameters.get("errorTechnicalReason");
			if (sErrorTechnicalReason) {
				jQuery.sap.log.warning("Handle lock conflict error");
				oMockErrorJSON.loadData(that._sMockErrorFilesUrl, {}, false);
				aMockRequests = oMockErrorJSON.getObject("/");
				aRequests.forEach(function(oEntry) {
					oMockRequest = aMockRequests.filter(
						function(e) {
							return oEntry.path.toString().indexOf(e.pathPatternKeyWord) > -1 &&
								oEntry.method === e.method &&
								e.errorType === "errorTechnicalReason" &&
								TechnicalConstant.CommodityCodeSet === e.pathPatternKeyWord;
						})[0];
					if (oMockRequest) {
						that._fnResponseJSON(500, oMockRequest.responseBody, oEntry);
					}
				});
			}
		},

		/**
		 * fake response 
		 * @param {int} iErrCode http status code
		 * @param {string} sMessage message in response
		 * @param {array} aRequest requestss
		 * @public
		 */
		_fnResponse: function(iErrCode, sMessage, aRequest) {
			aRequest.response = function(oXhr) {
				oXhr.respond(iErrCode, {
					"Content-Type": "text/plain;charset=utf-8"
				}, sMessage);
			};
		},

		/**
		 * fake empty response
		 * @param {array} aRequest requestss
		 * @public
		 */
		_fnResponseEmpty: function(aRequest) {
			aRequest.response = function(oXhr) {
				oXhr.respond(200, {
					"Content-Type": "application/json;charset=utf-8"
				}, '{"d":{"results":[]}}');
			};
		},

		/**
		 * fake response from json file
		 * @param {int} iErrCode http status code
		 * @param {string} sMessage message in response
		 * @param {array} aRequest requestss
		 * @public
		 */
		_fnResponseJSON: function(iErrCode, sMessage, aRequest) {
			aRequest.response = function(oXhr) {
				var sPath = oXhr.url.split("/sap/opu/odata/sap/SLL_CMDTYCD_MANAGE").join("") + "/",
					aError = [];
				if (sMessage.error.message && sMessage.error.message.value === "InternalError") {
					// internal error
					oXhr.respondJSON(500, {}, sMessage);
				} else {
					aError = sMessage.error.innererror.errordetails || sMessage.error.innererror || sMessage.error || sMessage;
					aError.forEach(function(oError) {
						oError.target = sPath + oError.target;
					});
					oXhr.respondJSON(iErrCode, {}, sMessage);
				}
			};
		},

		/**
		 * fake response from json file
		 * @param {string} sMessage message in response
		 * @param {array} aRequest requestss
		 * @public
		 */
		// _fnResponseConcurrencyConflict: function(sMessage, aRequest) {
		// 	aRequest.response = function(oXhr) {
		// 		var oRequestBody = JSON.parse(oXhr.requestBody);
		// 		if (oRequestBody.__metadata.etag && oRequestBody.__metadata.etag === "*") {
		// 			oXhr.respondJSON(204, {}, null);
		// 		} else {
		// 			oXhr.respondJSON(412, {}, sMessage);
		// 		}
		// 	};
		// },

		_fnResponseCommodityCodeNotFound: function(sMessage, oEntry) {
			oEntry.response = function(oXhr, sEntitySetName, sUrlParams) {
				oXhr.respondJSON(404, {}, sMessage);
			};
		},

		_fnResponseCommodityCodeGET: function(oEntry) {
			var that = this,
				fn = oEntry.response;
			oEntry.response = function(oXhr, sEntitySetName, sUrlParams) {
				fn(oXhr, sEntitySetName, sUrlParams);
				if (!that._oMockServer._bSLLDeleteItem) {
					that._oMockServer._bSLLDeleteItem = true;
					var aData = that._oMockServer.getEntitySetData("C_CommodityCodeByLanguage"),
						oObj = aData.filter(function(o) {
							return o.CommodityCode === "15011090";
						})[0],
						iIndex = aData.indexOf(oObj);
					if (iIndex >= 0) {
						aData.splice(iIndex, 1);
					}
					that._oMockServer.setEntitySetData("C_CommodityCodeByLanguage", aData);
				}
			};
		}
	});
});