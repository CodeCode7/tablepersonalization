/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/core/util/MockServer",
	"fcg/sll/cmdtycd/manages1/localService/mockrequest"
], function(MockServer, MockRequest) {
	"use strict";
	var oMockServer,
		_sAppModulePath = "fcg/sll/cmdtycd/manages1/",
		_sJsonFilesModulePath = _sAppModulePath + "localService/mockdata";

	return {

		/**
		 * Initializes the mock server.
		 * You can configure the delay with the URL parameter "serverDelay".
		 * The local mock data in this folder is returned instead of the real data for testing.
		 * @public
		 */
		init: function() {
			var oUriParameters = jQuery.sap.getUriParameters(),
				sJsonFilesUrl = jQuery.sap.getModulePath(_sJsonFilesModulePath),
				sManifestUrl = jQuery.sap.getModulePath(_sAppModulePath + "manifest", ".json"),
				oManifest = jQuery.sap.syncGetJSON(sManifestUrl).data,
				oMainDataSource = oManifest["sap.app"].dataSources.mainService,
				oDataSource = oManifest["sap.app"].dataSources,
				sMetadataUrl = jQuery.sap.getModulePath(_sAppModulePath + oMainDataSource.settings.localUri.replace(".xml", ""), ".xml"),
				// ensure there is a trailing slash
				sMockServerUrl = /.*\/$/.test(oMainDataSource.uri) ? oMainDataSource.uri : oMainDataSource.uri + "/",
				aAnnotations = oMainDataSource.settings.annotations,
				aRequests = [],
				oMockRequest,
				aMockEntitySetsNames = ["C_CommodityCodeByLanguage", "TrdClassfctnNmbrSchmCntntActnCtrlSet", "I_CmmdtyCodeNmbrSchmCntntStdVH", "I_CustomsUnitOfMeasureVH",
					"I_Language", "I_User"
				];

			oMockServer = new MockServer({
				rootUri: sMockServerUrl
			});

			// configure mock server with a delay of 1s
			MockServer.config({
				autoRespond: true,
				autoRespondAfter: (oUriParameters.get("serverDelay") || 1000)
			});

			// load local mock data
			oMockServer.simulate(sMetadataUrl, {
				sMockdataBaseUrl: sJsonFilesUrl,
				bGenerateMissingMockData: false,
				aEntitySetsNames: aMockEntitySetsNames
			});

			aRequests = oMockServer.getRequests();
			oMockRequest = new MockRequest(oUriParameters, sJsonFilesUrl, oMockServer);
			this._errorRequestHandler(oMockRequest, aRequests);

			oMockServer.start();

			jQuery.sap.log.info("Running the app with mock data");

			aAnnotations.forEach(function(sAnnotationName) {
				var oAnnotation = oDataSource[sAnnotationName],
					sUri = oAnnotation.uri,
					sLocalUri = jQuery.sap.getModulePath(_sAppModulePath + oAnnotation.settings.localUri.replace(".xml", ""), ".xml");

				///annotiaons
				new MockServer({
					rootUri: sUri,
					requests: [{
						method: "GET",
						path: new RegExp(/((\w|\W)+|)/),
						response: function(oXhr) {
							jQuery.sap.require("jquery.sap.xml");

							var oAnnotations = jQuery.sap.sjax({
								url: sLocalUri,
								dataType: "xml"
							}).data;

							oXhr.respondXML(200, {}, jQuery.sap.serializeXML(oAnnotations));
							return true;
						}
					}]

				}).start();

			});
		},

		/**
		 * @public returns the mockserver of the app, should be used in integration tests
		 * @returns {sap.ui.core.util.MockServer} the mockserver instance
		 */
		getMockServer: function() {
			return oMockServer;
		},

		/**
		 * @param {sap.ui.base.Object} oMockRequest mock server error object
		 * @param {array} aRequests request array
		 * @private handle error request
		 */
		_errorRequestHandler: function(oMockRequest, aRequests) {
			oMockRequest.onErrorRequestHandler(aRequests);
		}
	};

});